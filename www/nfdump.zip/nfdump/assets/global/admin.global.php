<?php
	##########################################
	# Manage Web Site Global Server-Side Script
	# MYSQL Configuration
	##########################################
	$MYSQL['_adminDB']						= "tbl_admin";
	$MYSQL['_companyDB']					= "tbl_company";
	$MYSQL['_userDB']						= "tbl_user";
	$MYSQL['_subjectDB']					= "tbl_subject";
	$MYSQL['_jobDB']						= "tbl_job";
	$MYSQL['_reportDB']						= "tbl_report";
	$MYSQL['_termsDB']						= "tbl_terms";

	$MYSQL['_categoryDB']						= "tbl_category";
	$MYSQL['_questDB']						= "tbl_quest";	
	$MYSQL['_answerDB']						= "tbl_answer";
	$MYSQL['_commentDB']						= "tbl_comment";	
	$MYSQL['_insuranceClaimDB']						= "tbl_insurance_claim";	
	
?>
<!-- ============================================================== -->
<!-- Start right Content here -->
<!-- ============================================================== -->
<div class="content-page">
    <!-- Start content -->
    <div class="content">
        <div class="container">
            <!-- Page-Title -->
            <div class="row">
                <div class="col-sm-6">
                    <h4 class="page-title">Edit Condition</h4>
                    <ol class="breadcrumb"> </ol>
                </div>
            </div>

            <div class="row">
                <div class="col-sm-12">
                    <div class="card-box table-responsive">
                        <form class="form-horizontal" role="form">
                            <div class="row">
                                <div class="col-lg-3">
                                    <h4 class="m-t-0 header-title"><b>Condition Edit</b></h4>
                                </div>
                                <div class="col-lg-4">
                                    <div class="form-group">
                                        <label class="col-md-2 control-label">Description</label>
                                        <div class="col-md-10">
                                            <input type="text" class="form-control" value="<?php echo $cond->descr; ?>">
                                        </div>
                                    </div>
                                </div>

                                <!-- <div class="col-lg-5">
                                    <div class="form-group">
                                        <label class="col-md-2 control-label">Filter</label>
                                        <div class="col-md-10">
                                            <input type="text" class="form-control" value="<?php echo $cond->filter_str; ?>">
                                        </div>
                                    </div>
                                </div> -->
                            </div>
                        </form>
                        <p class="text-muted m-b-30 font-13">
                            Please eidt filter on here.
                        </p>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-lg-12 ">
                    <ul class="nav nav-tabs tabs">
                        <li class="tab">
                            <a href="#t-version" data-toggle="tab" aria-expanded="false">Versions <span class="badge badge-primary">1</span></a>
                        </li>
                        <li class="tab">
                            <a href="#t-proto" data-toggle="tab" aria-expanded="false">Protocols<span class="badge badge-primary">2</span></a>
                        </li>
                        <li class="tab">
                            <a href="#t-ips" data-toggle="tab" aria-expanded="false">Addrs<span class="badge badge-primary">3,4</span></a>
                        </li>
                        <li class="tab">
                            <a href="#t-ports" data-toggle="tab" aria-expanded="false">Ports<span class="badge badge-primary">5,6</span></a>
                        </li>
                        <li class="tab">
                            <a href="#t-router" data-toggle="tab" aria-expanded="true">Routers<span class="badge badge-primary">7</span></a>
                        </li>
                        <li class="tab">
                            <a href="#t-subnet" data-toggle="tab" aria-expanded="true">SubNet<span class="badge badge-primary">8,9</span></a>
                        </li>
                        <li class="tab">
                            <a href="#t-as" data-toggle="tab" aria-expanded="true">AS<span class="badge badge-primary">10,11</span></a>
                        </li>
                        <li class="tab">
                            <a href="#t-inout" data-toggle="tab" aria-expanded="true">IN/OUT<span class="badge badge-primary">12,13</span></a>
                        </li>

                        <li class="tab">
                            <a href="#t-icmp" data-toggle="tab" aria-expanded="true">ICMP<span class="badge badge-primary">14</span></a>
                        </li>
                        <li class="tab">
                            <a href="#t-tcpflags" data-toggle="tab" aria-expanded="true">TcpFlags<span class="badge badge-primary">15</span></a>
                        </li>
                        <li class="tab">
                            <a href="#t-fwdstatus" data-toggle="tab" aria-expanded="true">Fwd Status<span class="badge badge-primary">16</span></a>
                        </li>
                        <li class="tab">
                            <a href="#t-opts" data-toggle="tab" aria-expanded="true">Options</a>
                        </li>
                    </ul>
                    <div class="tab-content" style="width:100%;">
                        <div class="tab-pane" id="t-version">
                            <div class="row">
                                <div class="col-lg-9">
                                    <table id="tbl_version" class="table table-striped table-bordered">
                                        <thead>
                                            <tr>
                                                <th>Protocol version</th>
                                                <th>Description</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        </tbody>
                                        <tfoot>
                                            <tr>
                                                <th>Protocol version</th>
                                                <th>Description</th>
                                                <th>Action</th>
                                            </tr>
                                        </tfoot>
                                    </table>
                                </div>
                                <div class="col-sm-3">
                                    <div class="card-box">
                                        <h4 class="m-t-0 header-title"><b>Add Version</b></h4>
                                        <form data-parsley-validate novalidate method="post" enctype="multipart/form-data">
                                            <div class="form-group">
                                                <label>Version</label>
                                                <select id="protocol_version" name="protocol_version" class="selectpicker" data-style="btn-default btn-custom">
                                                    <?php foreach ($versions as $version) { ?>
                                                        <option value="<?php echo $version->Id; ?>"><?php echo $version->name; ?></option>
                                                    <?php } ?>
                                                </select>
                                            </div>
                                            <div class="form-group text-right m-b-0">
                                                <button class="btn btn-primary waves-effect waves-light" type="button" onclick="addVersion()">
                                                    Add
                                                </button>
                                            </div>
                                        </form>
                                    </div>
                                </div>

                            </div>
                        </div>
                        <div class="tab-pane" id="t-proto">
                            <div class="row">
                                <div class="col-lg-9">
                                    <table id="tbl_protocol" class="table table-striped table-bordered">
                                        <thead>
                                            <tr>
                                                <th>Protocol</th>
                                                <th>Description</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        </tbody>
                                        <tfoot>
                                            <tr>
                                                <th>Protocol</th>
                                                <th>Description</th>
                                                <th>Action</th>
                                            </tr>
                                        </tfoot>
                                    </table>
                                </div>
                                <div class="col-sm-3">
                                    <div class="card-box">
                                        <h4 class="m-t-0 header-title"><b>Add Protocol</b></h4>
                                        <form data-parsley-validate novalidate method="post" enctype="multipart/form-data">
                                            <div class="form-group">
                                                <label>Protocol</label>
                                                <select id="protocol_id" name="protocol_id" class="selectpicker" data-style="btn-default btn-custom">
                                                    <?php foreach ($protos as $proto) { ?>
                                                        <option value="<?php echo $proto->Id; ?>"><?php echo $proto->name; ?></option>
                                                    <?php } ?>
                                                </select>
                                            </div>
                                            <div class="form-group text-right m-b-0">
                                                <button class="btn btn-primary waves-effect waves-light" type="button" onclick="addProtocol()">
                                                    Add
                                                </button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane active" id="t-ips">
                            <div class="row">
                                <div class="col-lg-9">
                                    <table id="tbl_ips" class="table table-striped table-bordered">
                                        <thead>
                                            <tr>
                                                <th>IP Address</th>
                                                <th>Form</th>
                                                <th>Description</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        </tbody>
                                        <tfoot>
                                            <tr>
                                                <th>IP Address</th>
                                                <th>Form</th>
                                                <th>Description</th>
                                                <th>Action</th>
                                            </tr>
                                        </tfoot>
                                    </table>
                                </div>
                                <div class="col-sm-3">
                                    <div class="card-box">
                                        <h4 class="m-t-0 header-title"><b>Add IP Address</b></h4>
                                        <form action="" data-parsley-validate novalidate method="post" enctype="multipart/form-data">
                                            <div class="form-group">
                                                <label>IP Address</label>
                                                <input id="ip_addr" name="ip_addr" class="form-control" type="text" placeholder="IP address" value="" />
                                            </div>
                                            <div class="form-group">
                                                <label>Form</label>
                                                <select id="ip_from" name="ip_from" class="selectpicker" data-style="btn-default btn-custom">
                                                    <option value="SRC" selected>SRC</option>
                                                    <option value="DST">DST</option>
                                                </select>
                                            </div>
                                            <div class="form-group">
                                                <label>Description</label>
                                                <input id="ip_descr" name="ip_descr" class="form-control" type="text" placeholder="Description" value="" />
                                            </div>
                                            <div class="form-group text-right m-b-0">
                                                <button class="btn btn-primary waves-effect waves-light" type="button" onclick="addIP()">
                                                    Add
                                                </button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane" id="t-ports">
                            <div class="row">
                                <div class="col-lg-9">
                                    <table id="tbl_ports" class="table table-striped table-bordered">
                                        <thead>
                                            <tr>
                                                <th>Port</th>
                                                <th>Form</th>
                                                <th>Description</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        </tbody>
                                        <tfoot>
                                            <tr>
                                                <th>Port</th>
                                                <th>Form</th>
                                                <th>Description</th>
                                                <th>Action</th>
                                            </tr>
                                        </tfoot>
                                    </table>
                                </div>
                                <div class="col-sm-3">
                                    <div class="card-box">
                                        <h4 class="m-t-0 header-title"><b>Add Port number</b></h4>
                                        <form action="" data-parsley-validate novalidate method="post" enctype="multipart/form-data">
                                            <div class="form-group">
                                                <label>Port</label>
                                                <input class="vertical-spin" type="text" value="" name="port" id="port" data-bts-min="1" data-bts-max="65535">
                                            </div>
                                            <div class="form-group">
                                                <label>Form</label>
                                                <select id="port_from" name="port_from" class="selectpicker" data-style="btn-default btn-custom">
                                                    <option value="SRC" selected>SRC</option>
                                                    <option value="DST">DST</option>
                                                </select>
                                            </div>
                                            <div class="form-group">
                                                <label>Description</label>
                                                <input id="port_descr" name="port_descr" class="form-control" type="text" placeholder="Description" value="" />
                                            </div>
                                            <div class="form-group text-right m-b-0">
                                                <button class="btn btn-primary waves-effect waves-light" type="button" onclick="addPort()">
                                                    Add
                                                </button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane" id="t-icmp">
                            <div class="row">
                                <div class="col-lg-9">
                                    <table id="tbl_icmp" class="table table-striped table-bordered">
                                        <thead>
                                            <tr>
                                                <th>Type</th>
                                                <th>Code</th>
                                                <th>Description</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        </tbody>
                                        <tfoot>
                                            <tr>
                                                <th>Type</th>
                                                <th>Code</th>
                                                <th>Description</th>
                                                <th>Action</th>
                                            </tr>
                                        </tfoot>
                                    </table>
                                </div>
                                <div class="col-sm-3">
                                    <div class="card-box">
                                        <h4 class="m-t-0 header-title"><b>Add ICMP Filter</b></h4>
                                        <form action="" data-parsley-validate novalidate method="post" enctype="multipart/form-data">
                                            <div class="form-group">
                                                <label>Type</label>
                                                <select id="icmp_type" name="icmp_type" class="selectpicker" data-style="btn-default btn-custom">
                                                    <?php foreach ($icmpTypes as $tp) { ?>
                                                        <option value="<?php echo $tp->Id; ?>"><?php echo $tp->name; ?></option>
                                                    <?php } ?>
                                                </select>
                                            </div>
                                            <div class="form-group">
                                                <label>Code</label>
                                                <input class="vertical-spin" type="text" value="" name="icmp_code" id="icmp_code" data-bts-min="0" data-bts-max="255">
                                            </div>
                                            <div class="form-group">
                                                <label>Description</label>
                                                <input id="icmp_descr" name="icmp_descr" class="form-control" type="text" placeholder="Description" value="" />
                                            </div>
                                            <div class="form-group text-right m-b-0">
                                                <button class="btn btn-primary waves-effect waves-light" type="button" onclick="addIcmp()">
                                                    Add
                                                </button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane" id="t-router">
                            <div class="row">
                                <div class="col-lg-9">
                                    <table id="tbl_router" class="table table-striped table-bordered">
                                        <thead>
                                            <tr>
                                                <th>Router</th>
                                                <th>Description</th>
                                                <th>Details</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        </tbody>
                                        <tfoot>
                                            <tr>
                                                <th>Router</th>
                                                <th>Description</th>
                                                <th>Details</th>
                                                <th>Action</th>
                                            </tr>
                                        </tfoot>
                                    </table>
                                </div>
                                <div class="col-sm-3">
                                    <div class="card-box">
                                        <h4 class="m-t-0 header-title"><b>Add router</b></h4>
                                        <form action="" data-parsley-validate novalidate method="post" enctype="multipart/form-data">
                                            <div class="form-group">
                                                <label>Router</label>
                                                <select id="router_id" name="router_id" class="selectpicker" data-style="btn-default btn-custom">
                                                    <?php foreach ($routers as $router) { ?>
                                                        <option value="<?php echo $router->Id; ?>"><?php echo $router->ip; ?></option>
                                                    <?php } ?>
                                                </select>
                                            </div>
                                            <div class="form-group text-right m-b-0">
                                                <button class="btn btn-primary waves-effect waves-light" type="button" onclick="addRouter()">
                                                    Add
                                                </button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane active" id="t-as">
                            <div class="row">
                                <div class="col-lg-9">
                                    <table id="tbl_as" class="table table-striped table-bordered">
                                        <thead>
                                            <tr>
                                                <th>AS number</th>
                                                <th>Form</th>
                                                <th>Description</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        </tbody>
                                        <tfoot>
                                            <tr>
                                                <th>AS number</th>
                                                <th>Form</th>
                                                <th>Description</th>
                                                <th>Action</th>
                                            </tr>
                                        </tfoot>
                                    </table>
                                </div>
                                <div class="col-sm-3">
                                    <div class="card-box">
                                        <h4 class="m-t-0 header-title"><b>Add AS</b></h4>
                                        <form action="" data-parsley-validate novalidate method="post" enctype="multipart/form-data">
                                            <div class="form-group">
                                                <label>AS number</label>
                                                <input id="as_num" name="as_num" class="form-control" type="text" placeholder="AS number" value="" />
                                            </div>
                                            <div class="form-group">
                                                <label>Form</label>
                                                <select id="as_from" name="as_from" class="selectpicker" data-style="btn-default btn-custom">
                                                    <option value="SRC" selected>SRC</option>
                                                    <option value="DST">DST</option>
                                                </select>
                                            </div>
                                            <div class="form-group">
                                                <label>Description</label>
                                                <input id="as_descr" name="as_descr" class="form-control" type="text" placeholder="Description" value="" />
                                            </div>
                                            <div class="form-group text-right m-b-0">
                                                <button class="btn btn-primary waves-effect waves-light" type="button" onclick="addAS()">
                                                    Add
                                                </button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane active" id="t-inout">
                            <div class="row">
                                <div class="col-lg-9">
                                    <table id="tbl_inout" class="table table-striped table-bordered">
                                        <thead>
                                            <tr>
                                                <th>IN/OUT number</th>
                                                <th>Form</th>
                                                <th>Description</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        </tbody>
                                        <tfoot>
                                            <tr>
                                                <th>IN/OUT number</th>
                                                <th>Form</th>
                                                <th>Description</th>
                                                <th>Action</th>
                                            </tr>
                                        </tfoot>
                                    </table>
                                </div>
                                <div class="col-sm-3">
                                    <div class="card-box">
                                        <h4 class="m-t-0 header-title"><b>Add IN/OUT</b></h4>
                                        <form action="" data-parsley-validate novalidate method="post" enctype="multipart/form-data">
                                            <div class="form-group">
                                                <label>IN/OUT number</label>
                                                <input id="inout_num" name="inout_num" class="form-control" type="text" placeholder="number" value="" />
                                            </div>
                                            <div class="form-group">
                                                <label>Form</label>
                                                <select id="inout_from" name="inout_from" class="selectpicker" data-style="btn-default btn-custom">
                                                    <option value="INPUT" selected>INPUT</option>
                                                    <option value="OUTPUT">OUTPUT</option>
                                                </select>
                                            </div>
                                            <div class="form-group">
                                                <label>Description</label>
                                                <input id="inout_descr" name="inout_descr" class="form-control" type="text" placeholder="Description" value="" />
                                            </div>
                                            <div class="form-group text-right m-b-0">
                                                <button class="btn btn-primary waves-effect waves-light" type="button" onclick="addInOut()">
                                                    Add
                                                </button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="tab-pane" id="t-tcpflags">
                            <div class="row">
                                <div class="col-lg-9">
                                    <table id="tbl_tcp_flag" class="table table-striped table-bordered">
                                        <thead>
                                            <tr>
                                                <th>Value</th>
                                                <th>Description</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        </tbody>
                                        <tfoot>
                                            <tr>
                                                <th>Value</th>
                                                <th>Description</th>
                                                <th>Action</th>
                                            </tr>
                                        </tfoot>
                                    </table>
                                </div>
                                <div class="col-sm-3">
                                    <div class="card-box">
                                        <h4 class="m-t-0 header-title"><b>Add TCP Flags</b></h4>
                                        <form action="" data-parsley-validate novalidate method="post" enctype="multipart/form-data">
                                            <div class="form-group">
                                                <label>Flag</label>
                                                <select id="tcp_flag" name="tcp_flag" class="selectpicker" data-style="btn-default btn-custom">
                                                    <?php foreach ($tcpFlags as $tf) { ?>
                                                        <option value="<?php echo $tf->value; ?>"><?php echo $tf->descr; ?></option>
                                                    <?php } ?>
                                                </select>
                                            </div>
                                            <div class="form-group text-right m-b-0">
                                                <button class="btn btn-primary waves-effect waves-light" type="button" onclick="addTcpFlag();">
                                                    Add
                                                </button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane" id="t-fwdstatus">
                            <div class="row">
                                <div class="col-lg-9">
                                    <table id="tbl_fwd_status" class="table table-striped table-bordered">
                                        <thead>
                                            <tr>
                                                <th>Value</th>
                                                <th>Description</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        </tbody>
                                        <tfoot>
                                            <tr>
                                                <th>Value</th>
                                                <th>Description</th>
                                                <th>Action</th>
                                            </tr>
                                        </tfoot>
                                    </table>
                                </div>
                                <div class="col-sm-3">
                                    <div class="card-box">
                                        <h4 class="m-t-0 header-title"><b>Add Forward status</b></h4>
                                        <form action="" data-parsley-validate novalidate method="post" enctype="multipart/form-data">
                                            <div class="form-group">
                                                <label>Status</label>
                                                <select id="fwd_status" name="fwd_status" class="selectpicker" data-style="btn-default btn-custom">
                                                    <?php foreach ($fwdStatus as $fs) { ?>
                                                        <option value="<?php echo $fs->value; ?>"><?php echo $fs->descr; ?></option>
                                                    <?php } ?>
                                                </select>
                                            </div>
                                            <div class="form-group text-right m-b-0">
                                                <button class="btn btn-primary waves-effect waves-light" type="button" onclick="addFwdStatus();">
                                                    Add
                                                </button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane" id="t-subnet">
                            <div class="row">
                                <div class="col-lg-9">
                                    <table id="tbl_subnet" class="table table-striped table-bordered">
                                        <thead>
                                            <tr>
                                                <th>SubNet</th>
                                                <th>Mask</th>
                                                <th>Form</th>
                                                <th>Description</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        </tbody>
                                        <tfoot>
                                            <tr>
                                                <th>SubNet</th>
                                                <th>Mask</th>
                                                <th>Form</th>
                                                <th>Description</th>
                                                <th>Action</th>
                                            </tr>
                                        </tfoot>
                                    </table>
                                </div>
                                <div class="col-sm-3">
                                    <div class="card-box">
                                        <h4 class="m-t-0 header-title"><b>Add SubNet</b></h4>
                                        <form action="" data-parsley-validate novalidate method="post" enctype="multipart/form-data">
                                            <div class="form-group">
                                                <label>Subnet</label>
                                                <input id="subnet" class="form-control" type="text" placeholder="IP address" value="" />
                                            </div>
                                            <div class="form-group">
                                                <label>Mask</label>
                                                <input id="subnet_mask" class="form-control" type="text" placeholder="Mask" value="" />
                                            </div>
                                            <div class="form-group">
                                                <label>Form</label>
                                                <select id="subnet_from" name="subnet_from" class="selectpicker" data-style="btn-default btn-custom">
                                                    <option value="SRC" selected>SRC</option>
                                                    <option value="DST">DST</option>
                                                </select>
                                            </div>
                                            <div class="form-group">
                                                <label>Description</label>
                                                <input id="subnet_descr" class="form-control" type="text" placeholder="Description" value="" />
                                            </div>
                                            <div class="form-group text-right m-b-0">
                                                <button class="btn btn-primary waves-effect waves-light" type="button" onclick="addSubNet();">
                                                    Add
                                                </button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane" id="t-opts">
                            <form action="<?php echo base_url() . 'Cms_api/save_condition_opts' ?>" data-parsley-validate novalidate method="post" enctype="multipart/form-data">
                                <input type="hidden" name="cond_id" id="cond_id" value="<?php echo $cond_id; ?>" />
                                <div class="row">
                                    <div class="col-lg-6">
                                        <div class="card-box">
                                            <table class="table table-bordered table-striped">
                                                <thead>
                                                    <tr>
                                                        <th><i class="icon-settings"></i> Option</th>
                                                        <th><i class="ion-checkmark-circled"></i> Enable</th>
                                                        <th><i class="ion-ios7-paper-outline"></i> Content</th>
                                                        <th><i class="ion-shuffle"></i> Compare</th>
                                                        <th><i class="ion-qr-scanner"></i> Scale</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        <th>Addrs Filter</th>
                                                        <td>
                                                            <input type="checkbox" name="ips_enable" id="ips_enable" <?php if ($cond->ips_enable == "on") echo 'checked'; ?> data-plugin="switchery" data-color="#f05050" data-size="small" />
                                                        </td>
                                                        <td>
                                                            <div class="radio radio-pink radio-inline">
                                                                <input type="radio" <?php if ($cond->ips_comp == 'AND') echo 'checked'; ?> name="ips_comp" id="ips_comp" value="AND">
                                                                <label for="radio8">AND</label>
                                                            </div>
                                                            <div class="radio radio-primary radio-inline">
                                                                <input type="radio" <?php if ($cond->ips_comp == 'OR') echo 'checked'; ?> name="ips_comp" id="ips_comp" value="OR">
                                                                <label for="radio9">OR</label>
                                                            </div>

                                                        </td>
                                                    </tr>

                                                    <tr>
                                                        <th>Port Filter</th>
                                                        <td>
                                                            <input type="checkbox" name="ports_enable" id="ports_enable" <?php if ($cond->ports_enable == "on") echo 'checked'; ?> data-plugin="switchery" data-color="#f05050" data-size="small" />
                                                        </td>
                                                        <td>
                                                            <div class="radio radio-pink radio-inline">
                                                                <input type="radio" <?php if ($cond->ports_comp == 'AND') echo 'checked'; ?> name="ports_comp" id="ports_comp" value="AND">
                                                                <label for="radio8">AND</label>
                                                            </div>
                                                            <div class="radio radio-primary radio-inline">
                                                                <input type="radio" <?php if ($cond->ports_comp == 'OR') echo 'checked'; ?> name="ports_comp" id="ports_comp" value="OR">
                                                                <label for="radio9">OR</label>
                                                            </div>

                                                        </td>
                                                    </tr>

                                                    <tr>
                                                        <th>Router Filter</th>
                                                        <td>
                                                            <input type="checkbox" name="routers_enable" id="routers_enable" <?php if ($cond->routers_enable == "on") echo 'checked'; ?> data-plugin="switchery" data-color="#f05050" data-size="small" />
                                                        </td>
                                                        <td>
                                                            <div class="radio radio-pink radio-inline">
                                                                <input type="radio" <?php if ($cond->routers_comp == 'AND') echo 'checked'; ?> name="routers_comp" id="routers_comp" value="AND">
                                                                <label for="radio8">AND</label>
                                                            </div>
                                                            <div class="radio  radio-primary radio-inline">
                                                                <input type="radio" <?php if ($cond->routers_comp == 'OR') echo 'checked'; ?> name="routers_comp" id="routers_comp" value="OR">
                                                                <label for="radio9">OR</label>
                                                            </div>

                                                        </td>
                                                    </tr>

                                                    <tr>
                                                        <th>Subnet Filter</th>
                                                        <td>
                                                            <input type="checkbox" name="subnets_enable" id="subnets_enable" <?php if ($cond->subnets_enable == "on") echo 'checked'; ?> data-plugin="switchery" data-color="#f05050" data-size="small" />
                                                        </td>
                                                        <td>
                                                            <div class="radio radio-pink radio-inline">
                                                                <input type="radio" <?php if ($cond->subnets_comp == 'AND') echo 'checked'; ?> name="subnets_comp" id="subnets_comp" value="AND">
                                                                <label for="radio8">AND</label>
                                                            </div>
                                                            <div class="radio  radio-primary radio-inline">
                                                                <input type="radio" <?php if ($cond->subnets_comp == 'OR') echo 'checked'; ?> name="subnets_comp" id="subnets_comp" value="OR">
                                                                <label for="radio9">OR</label>
                                                            </div>

                                                        </td>
                                                    </tr>

                                                    <tr>
                                                        <th>AS Filter</th>
                                                        <td>
                                                            <input type="checkbox" name="as_enable" id="as_enable" <?php if ($cond->as_enable == "on") echo 'checked'; ?> data-plugin="switchery" data-color="#f05050" data-size="small" />
                                                        </td>
                                                        <td>
                                                            <div class="radio radio-pink radio-inline">
                                                                <input type="radio" <?php if ($cond->as_comp == 'AND') echo 'checked'; ?> name="as_comp" id="as_comp" value="AND">
                                                                <label for="radio8">AND</label>
                                                            </div>
                                                            <div class="radio  radio-primary radio-inline">
                                                                <input type="radio" <?php if ($cond->as_comp == 'OR') echo 'checked'; ?> name="as_comp" id="as_comp" value="OR">
                                                                <label for="radio9">OR</label>
                                                            </div>

                                                        </td>
                                                    </tr>

                                                    <tr>
                                                        <th>IN/OUT Filter</th>
                                                        <td>
                                                            <input type="checkbox" name="inouts_enable" id="inouts_enable" <?php if ($cond->inouts_enable == "on") echo 'checked'; ?> data-plugin="switchery" data-color="#f05050" data-size="small" />
                                                        </td>
                                                        <td>
                                                            <div class="radio radio-pink radio-inline">
                                                                <input type="radio" <?php if ($cond->inouts_comp == 'AND') echo 'checked'; ?> name="inouts_comp" id="inouts_comp" value="AND">
                                                                <label for="radio8">AND</label>
                                                            </div>
                                                            <div class="radio  radio-primary radio-inline">
                                                                <input type="radio" <?php if ($cond->inouts_comp == 'OR') echo 'checked'; ?> name="inouts_comp" id="inouts_comp" value="OR">
                                                                <label for="radio9">OR</label>
                                                            </div>

                                                        </td>
                                                    </tr>

                                                    <tr>
                                                        <th>ICMP Filter</th>
                                                        <td>
                                                            <input type="checkbox" name="icmp_enable" id="icmp_enable" <?php if ($cond->subnets_enable == "on") echo 'checked'; ?> data-plugin="switchery" data-color="#f05050" data-size="small" />
                                                        </td>
                                                        <td>
                                                            <div class="radio radio-pink radio-inline">
                                                                <input type="radio" <?php if ($cond->icmp_comp == 'AND') echo 'checked'; ?> name="icmp_comp" id="icmp_comp" value="AND">
                                                                <label for="radio8">AND</label>
                                                            </div>
                                                            <div class="radio  radio-primary radio-inline">
                                                                <input type="radio" <?php if ($cond->icmp_comp == 'OR') echo 'checked'; ?> name="icmp_comp" id="icmp_comp" value="OR">
                                                                <label for="radio9">OR</label>
                                                            </div>

                                                        </td>
                                                    </tr>

                                                    <tr>
                                                        <th>TCP Flags</th>
                                                        <td>
                                                            <input type="checkbox" name="tcpflags_enable" id="tcpflags_enable" <?php if ($cond->tcpflags_enable == "on") echo 'checked'; ?> data-plugin="switchery" data-color="#f05050" data-size="small" />
                                                        </td>
                                                        <td>
                                                            <div class="radio radio-pink radio-inline">
                                                                <input type="radio" <?php if ($cond->tcpflags_comp == 'AND') echo 'checked'; ?> name="tcpflags_comp" id="tcpflags_comp" value="AND">
                                                                <label for="radio8">AND</label>
                                                            </div>
                                                            <div class="radio  radio-primary radio-inline">
                                                                <input type="radio" <?php if ($cond->tcpflags_comp == 'OR') echo 'checked'; ?> name="tcpflags_comp" id="tcpflags_comp" value="OR">
                                                                <label for="radio9">OR</label>
                                                            </div>

                                                        </td>
                                                    </tr>

                                                    <tr>
                                                        <th>FWD Status</th>
                                                        <td>
                                                            <input type="checkbox" name="fwdstatus_enable" id="fwdstatus_enable" <?php if ($cond->tcpflags_enable == "on") echo 'checked'; ?> data-plugin="switchery" data-color="#f05050" data-size="small" />
                                                        </td>
                                                        <td>
                                                            <div class="radio radio-pink radio-inline">
                                                                <input type="radio" <?php if ($cond->fwdstatus_comp == 'AND') echo 'checked'; ?> name="fwdstatus_comp" id="fwdstatus_comp" value="AND">
                                                                <label for="radio8">AND</label>
                                                            </div>
                                                            <div class="radio  radio-primary radio-inline">
                                                                <input type="radio" <?php if ($cond->fwdstatus_comp == 'OR') echo 'checked'; ?> name="fwdstatus_comp" id="fwdstatus_comp" value="OR">
                                                                <label for="radio9">OR</label>
                                                            </div>

                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="card-box">
                                            <table class="table table-bordered table-striped">
                                                <thead>
                                                    <tr>
                                                        <th><i class="icon-settings"></i> Option</th>
                                                        <th><i class="ion-checkmark-circled"></i> Enable</th>
                                                        <th><i class="ion-ios7-paper-outline"></i> Content</th>
                                                        <th><i class="ion-shuffle"></i> Compare</th>
                                                        <th><i class="ion-qr-scanner"></i> Scale</th>
                                                    </tr>
                                                </thead>
                                                <tbody>

                                                    <tr>
                                                        <th>TOS</th>
                                                        <td>
                                                            <input type="checkbox" name="tos_enable" id="tos_enable" <?php if ($cond->tos_enable == "on") echo 'checked'; ?> data-plugin="switchery" data-color="#f05050" data-size="small" />
                                                        </td>
                                                        <td>
                                                            <input class="vertical-spin" type="text" value="<?php echo $cond->tos; ?>" name="tos" data-bts-min="0" data-bts-max="255">
                                                        </td>
                                                    </tr>

                                                    <tr>
                                                        <th>Packets</th>
                                                        <td>
                                                            <input type="checkbox" name="packets_enable" id="packets_enable" <?php if ($cond->packets_enable == "on") echo 'checked'; ?> data-plugin="switchery" data-color="#f05050" data-size="small" />
                                                        </td>
                                                        <td>
                                                            <input class="vertical-spin" type="text" value="<?php echo $cond->packets; ?>" name="packets" data-bts-min="0" data-bts-max="65535">
                                                        </td>
                                                        <td>
                                                            <select class="selectpicker" name="packets_comp" id="packets_comp" data-style="btn-default btn-custom">
                                                                <option value="EQ" <?php if ($cond->packets_comp == "EQ") echo 'selected'; ?>>EQ</option>
                                                                <option value="LT" <?php if ($cond->packets_comp == "LT") echo 'selected'; ?>>LT</option>
                                                                <option value="GT" <?php if ($cond->packets_comp == "GT") echo 'selected'; ?>>GT</option>
                                                            </select>
                                                        </td>
                                                    </tr>

                                                    <tr>
                                                        <th>Bytes</th>
                                                        <td>
                                                            <input type="checkbox" name="bytes_enable" id="bytes_enable" <?php if ($cond->bytes_enable == "on") echo 'checked'; ?> data-plugin="switchery" data-color="#f05050" data-size="small" />
                                                        </td>
                                                        <td>
                                                            <input class="vertical-spin" type="text" value="<?php echo $cond->bytes; ?>" name="bytes" data-bts-min="0" data-bts-max="65535">
                                                        </td>
                                                        <td>
                                                            <select class="selectpicker" name="bytes_comp" id="bytes_comp" data-style="btn-default btn-custom">
                                                                <option value="EQ" <?php if ($cond->bytes_comp == "EQ") echo 'selected'; ?>>EQ</option>
                                                                <option value="LT" <?php if ($cond->bytes_comp == "LT") echo 'selected'; ?>>LT</option>
                                                                <option value="GT" <?php if ($cond->bytes_comp == "GT") echo 'selected'; ?>>GT</option>
                                                            </select>
                                                        </td>
                                                        <td>
                                                            <select class="selectpicker" name="bytes_scale" id="bytes_scale" data-style="btn-default btn-custom">
                                                                <option value="1024" <?php if ($cond->bytes_scale == 1024) echo 'selected'; ?>>1024</option>
                                                                <option value="1048576‬" <?php if ($cond->bytes_scale == 1048576) echo 'selected'; ?>>1048576‬</option>
                                                            </select>
                                                        </td>
                                                    </tr>

                                                    <tr>
                                                        <th>Packets/Sec</th>
                                                        <td>
                                                            <input type="checkbox" name="packets_ps_enable" id="packets_ps_enable" <?php if ($cond->packets_ps_enable == "on") echo 'checked'; ?> data-plugin="switchery" data-color="#f05050" data-size="small" />
                                                        </td>
                                                        <td>
                                                            <input class="vertical-spin" type="text" value="<?php echo $cond->packets_ps; ?>" name="packets_ps" data-bts-min="0" data-bts-max="65535">
                                                        </td>
                                                        <td>
                                                            <select class="selectpicker" name="packets_ps_comp" id="packets_ps_comp" data-style="btn-default btn-custom">
                                                                <option value="EQ" <?php if ($cond->packets_ps_comp == "EQ") echo 'selected'; ?>>EQ</option>
                                                                <option value="LT" <?php if ($cond->packets_ps_comp == "LT") echo 'selected'; ?>>LT</option>
                                                                <option value="GT" <?php if ($cond->packets_ps_comp == "GT") echo 'selected'; ?>>GT</option>
                                                            </select>
                                                        </td>
                                                        <td>
                                                            <select class="selectpicker" name="packets_ps_scale" id="packets_ps_scale" data-style="btn-default btn-custom">
                                                                <option value="1024" <?php if ($cond->packets_ps_scale == 1024) echo 'selected'; ?>>1024</option>
                                                                <option value="1048576‬" <?php if ($cond->packets_ps_scale == 1048576) echo 'selected'; ?>>1048576‬</option>
                                                            </select>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <th>Duration</th>
                                                        <td>
                                                            <input type="checkbox" name="duration_enable" id="duration_enable" <?php if ($cond->duration_enable == "on") echo 'checked'; ?> data-plugin="switchery" data-color="#f05050" data-size="small" />
                                                        </td>
                                                        <td>
                                                            <input class="vertical-spin" type="text" value="<?php echo $cond->duration; ?>" name="duration" data-bts-min="0" data-bts-max="65535">
                                                        </td>
                                                        <td>
                                                            <select class="selectpicker" name="duration_comp" id="duration_comp" data-style="btn-default btn-custom">
                                                                <option value="EQ" <?php if ($cond->duration_comp == "EQ") echo 'selected'; ?>>EQ</option>
                                                                <option value="LT" <?php if ($cond->duration_comp == "LT") echo 'selected'; ?>>LT</option>
                                                                <option value="GT" <?php if ($cond->duration_comp == "GT") echo 'selected'; ?>>GT</option>
                                                            </select>
                                                        </td>
                                                    </tr>

                                                    <tr>
                                                        <th>Bytes/Sec</th>
                                                        <td>
                                                            <input type="checkbox" name="bps_enable" id="bps_enable" <?php if ($cond->bps_enable == "on") echo 'checked'; ?> data-plugin="switchery" data-color="#f05050" data-size="small" />
                                                        </td>
                                                        <td>
                                                            <input class="vertical-spin" type="text" value="<?php echo $cond->bps; ?>" name="bps" data-bts-min="0" data-bts-max="65535">
                                                        </td>
                                                        <td>
                                                            <select class="selectpicker" name="bps_comp" id="bps_comp" data-style="btn-default btn-custom">
                                                                <option value="EQ" <?php if ($cond->bps_comp == "EQ") echo 'selected'; ?>>EQ</option>
                                                                <option value="LT" <?php if ($cond->bps_comp == "LT") echo 'selected'; ?>>LT</option>
                                                                <option value="GT" <?php if ($cond->bps_comp == "GT") echo 'selected'; ?>>GT</option>
                                                            </select>
                                                        </td>
                                                        <td>
                                                            <select class="selectpicker" name="bps_scale" id="bps_scale" data-style="btn-default btn-custom">
                                                                <option value="1024" <?php if ($cond->bps_scale == 1024) echo 'selected'; ?>>1024</option>
                                                                <option value="1048576‬" <?php if ($cond->bps_scale == 1048576) echo 'selected'; ?>>1048576‬</option>
                                                            </select>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <th>Bytes/Packet</th>
                                                        <td>
                                                            <input type="checkbox" name="bpp_enable" id="bpp_enable" <?php if ($cond->bpp_enable == "on") echo 'checked'; ?> data-plugin="switchery" data-color="#f05050" data-size="small" />
                                                        </td>
                                                        <td>
                                                            <input class="vertical-spin" type="text" value="<?php echo $cond->bpp; ?>" name="bpp" data-bts-min="0" data-bts-max="65535">
                                                        </td>
                                                        <td>
                                                            <select class="selectpicker" name="bpp_comp" id="bpp_comp" data-style="btn-default btn-custom">
                                                                <option value="EQ" <?php if ($cond->bpp_comp == "EQ") echo 'selected'; ?>>EQ</option>
                                                                <option value="LT" <?php if ($cond->bpp_comp == "LT") echo 'selected'; ?>>LT</option>
                                                                <option value="GT" <?php if ($cond->bpp_comp == "GT") echo 'selected'; ?>>GT</option>
                                                            </select>
                                                        </td>
                                                        <td>
                                                            <select class="selectpicker" name="bpp_scale" id="bpp_scale" data-style="btn-default btn-custom">
                                                                <option value="1024" <?php if ($cond->bpp_scale == 1024) echo 'selected'; ?>>1024</option>
                                                                <option value="1048576‬" <?php if ($cond->bpp_scale == 1048576) echo 'selected'; ?>>1048576‬</option>
                                                            </select>
                                                        </td>
                                                    </tr>

                                                    <!-- <tr>
                                                            <th>AS</th>
                                                            <td>
                                                                <input type="checkbox" <?php if ($cond->as_enable) echo 'checked'; ?> data-plugin="switchery" data-color="#f05050" data-size="small" />
                                                            </td>
                                                            <td>
                                                                <input class="form-control" type="text" name="as" id="as" placeholder="" />
                                                            </td>
                                                        </tr> -->

                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group text-right m-b-0">
                                    <button class="btn btn-primary waves-effect waves-light" type="submit">
                                        Save
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

            <!-- <div class="row">
                <div class="col-sm-6">
                    <div class="card-box">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th><i class="icon-settings"></i> Option</th>
                                    <th><i class="ion-checkmark-circled"></i> Enable</th>
                                    <th><i class="ion-ios7-paper-outline"></i> Content</th>
                                    <th><i class="ion-shuffle"></i> Compare</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <th>Version</th>
                                    <td>
                                        <input type="checkbox" id="protocol_version_enable" name="protocol_version_enable" <?php if ($cond->protocol_version_enable) echo 'checked'; ?> data-plugin="switchery" data-color="#f05050" data-size="small" />
                                    </td>
                                    <td>
                                        <select id="protocol_version" name="protocol_version" class="selectpicker" data-style="btn-default btn-custom">
                                            <option value="inet" <?php if ($cond->protocol_version == 'inet') echo 'selected'; ?>>inet</option>
                                            <option value="ipv4" <?php if ($cond->protocol_version == 'ipv4') echo 'selected'; ?>>ipv4</option>
                                            <option value="inet6" <?php if ($cond->protocol_version == 'inet6') echo 'selected'; ?>>inet6</option>
                                            <option value="ipv6" <?php if ($cond->protocol_version == 'ipv6') echo 'selected'; ?>>ipv6</option>
                                        </select>
                                    </td>
                                </tr>

                                <tr>
                                    <th>Protocol</th>
                                    <td>
                                        <input type="checkbox" id="protocol_enable" name="protocol_enable" <?php if ($cond->protocol_enable) echo 'checked'; ?> data-plugin="switchery" data-color="#f05050" data-size="small" />
                                    </td>
                                    <td>
                                        <select id="protocol" name="protocol" class="selectpicker" data-style="btn-default btn-custom">
                                            <option value="TCP" <?php if ($cond->protocol == 'TCP') echo 'selected'; ?>>TCP</option>
                                            <option value="UDP" <?php if ($cond->protocol == 'UDP') echo 'selected'; ?>>UDP</option>
                                            <option value="ICMP" <?php if ($cond->protocol == 'ICMP') echo 'selected'; ?>>ICMP</option>
                                            <option value="GRE" <?php if ($cond->protocol == 'GRE') echo 'selected'; ?>>GRE</option>
                                            <option value="ESP" <?php if ($cond->protocol == 'ESP') echo 'selected'; ?>>ESP</option>
                                            <option value="AH" <?php if ($cond->protocol == 'AH') echo 'selected'; ?>>AH</option>
                                            <option value="RSVP" <?php if ($cond->protocol == 'RSVP') echo 'selected'; ?>>RSVP</option>
                                        </select>
                                    </td>
                                </tr>

                                <tr>
                                    <th>Source IP</th>
                                    <td>
                                        <input type="checkbox" id="src_ip_enable" name="src_ip_enable" <?php if ($cond->src_ip_enable) echo 'checked'; ?> data-plugin="switchery" data-color="#f05050" data-size="small" />
                                    </td>
                                    <td>
                                        <input id="src_ip" name="src_ip" class="form-control" type="text" name="src_ip" id="src_ip" placeholder="Source IP" value="<?php echo $cond->src_ip; ?>" />
                                    </td>
                                </tr>

                                <tr>
                                    <th>Destination IP</th>
                                    <td>
                                        <input type="checkbox" id="dst_ip_enable" name="dst_ip_enable" <?php if ($cond->src_ip_enable) echo 'checked'; ?> data-plugin="switchery" data-color="#f05050" data-size="small" />
                                    </td>
                                    <td>
                                        <input id="dst_ip_enable" name="dst_ip_enable" class="form-control" type="text" name="dst_ip" id="dst_ip" placeholder="Destination IP" value="<?php echo $cond->dst_ip; ?>" />
                                    </td>
                                </tr>

                                <tr>
                                    <th>SRC/DST</th>
                                    <td></td>
                                    <td>
                                        <select class="selectpicker" data-style="btn-default btn-custom">
                                            <option value="and" <?php if ($cond->protocol == 'and') echo 'selected'; ?>>and</option>
                                            <option value="or" <?php if ($cond->protocol == 'or') echo 'selected'; ?>>or</option>
                                            <option value="not" <?php if ($cond->protocol == 'not') echo 'selected'; ?>>not</option>
                                        </select>
                                    </td>
                                </tr>

                                <tr>
                                    <th>Port</th>
                                    <td>
                                        <input type="checkbox" <?php if ($cond->port_enable) echo 'checked'; ?> data-plugin="switchery" data-color="#f05050" data-size="small" />
                                    </td>
                                    <td>
                                        <input class="vertical-spin" type="text" value="<?php echo $cond->port; ?>" name="port" data-bts-min="1" data-bts-max="65535">
                                    </td>
                                    <td>
                                        <select class="selectpicker" data-style="btn-default btn-custom">
                                            <option value="EQ" <?php if ($cond->port_comp == 'EQ') echo 'selected'; ?>>EQ</option>
                                            <option value="LT" <?php if ($cond->port_comp == 'LT') echo 'selected'; ?>>LT</option>
                                            <option value="GT" <?php if ($cond->port_comp == 'GT') echo 'selected'; ?>>GT</option>
                                        </select>
                                    </td>
                                </tr>

                                <tr>
                                    <th>Network</th>
                                    <td>
                                        <input type="checkbox" <?php if ($cond->network_enable) echo 'checked'; ?> data-plugin="switchery" data-color="#f05050" data-size="small" />
                                    </td>
                                    <td>
                                        <input class="form-control" type="text" name="network" id="network" placeholder="0.0.0.0/16" value="<?php echo $cond->network; ?>" />
                                    </td>
                                </tr>
                                <tr>
                                    <th>Interface</th>
                                    <td>
                                        <input type="checkbox" <?php if ($cond->interface_enable) echo 'checked'; ?> data-plugin="switchery" data-color="#f05050" data-size="small" />
                                    </td>
                                    <td>
                                        <input class="vertical-spin" type="text" value="<?php echo $cond->interface; ?>" name="interface" data-bts-min="1" data-bts-max="16">
                                    </td>
                                </tr>


                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="col-sm-6">
                </div>
            </div> -->

        </div> <!-- container -->
    </div> <!-- content -->
</div> <!-- content-page -->
</div>
<!-- END wrapper -->

<script src="<?php echo base_url('assets/plugins/switchery/js/switchery.min.js'); ?>"></script>

<script type="text/javascript">
    function initTable(tagId, cols, dataUrl) {
        var tblObj = $(tagId).DataTable({
            dom: "lfBrtip",
            buttons: [{
                extend: "copy",
                className: "btn-sm"
            }, {
                extend: "csv",
                className: "btn-sm"
            }, {
                extend: "excel",
                className: "btn-sm"
            }, {
                extend: "pdf",
                className: "btn-sm"
            }, {
                extend: "print",
                className: "btn-sm"
            }],
            responsive: !0,
            processing: true,
            serverSide: false,
            sPaginationType: "full_numbers",
            language: {
                paginate: {
                    next: '<i class="fa fa-angle-right"></i>',
                    previous: '<i class="fa fa-angle-left"></i>',
                    first: '<i class="fa fa-angle-double-left"></i>',
                    last: '<i class="fa fa-angle-double-right"></i>'
                }
            },
            //Set column definition initialisation properties.
            columnDefs: cols,
            ajax: {
                url: dataUrl,
                type: "POST",
            },
        });
        return tblObj;
    }

    var tableName = "<?php echo $table; ?>";
    var condId = "<?php echo $cond_id; ?>";
    var tblVersion, tblProtocol, tblIP, tblPort, tblIcmp, tblRouter, tblAS, tblInOut;
    var tblTcpFlags, tblFwdStatus;

    tblVersion = initTable("#tbl_version",
        [{
                targets: [0], //first column 
                orderable: true, //set not orderable
                className: "dt-center"
            },
            {
                targets: [1], //first column 
                orderable: false, //set not orderable
                className: "dt-center"
            },
            {
                targets: [-1], //last column
                orderable: false, //set not orderable
                className: "actions dt-center"
            }
        ], "<?php echo site_url('Cms_api/get_cond_versions/' . $cond_id) ?>");

    tblProtocol = initTable("#tbl_protocol",
        [{
                targets: [0], //first column 
                orderable: true, //set not orderable
                className: "dt-center"
            },
            {
                targets: [1], //first column 
                orderable: false, //set not orderable
                className: "dt-center"
            },
            {
                targets: [-1], //last column
                orderable: false, //set not orderable
                className: "actions dt-center"
            }
        ], "<?php echo site_url('Cms_api/get_cond_protocols/' . $cond_id) ?>");

    tblIP = initTable("#tbl_ips",
        [{
                targets: [0], //first column 
                orderable: true, //set not orderable
                className: "dt-center"
            },
            {
                targets: [1], //first column 
                orderable: false, //set not orderable
                className: "dt-center"
            },
            {
                targets: [2], //first column 
                orderable: false, //set not orderable
                className: "dt-center"
            },
            {
                targets: [-1], //last column
                orderable: false, //set not orderable
                className: "actions dt-center"
            }
        ], "<?php echo site_url('Cms_api/get_cond_ips/' . $cond_id) ?>");

    tblAS = initTable("#tbl_as",
        [{
                targets: [0], //first column 
                orderable: true, //set not orderable
                className: "dt-center"
            },
            {
                targets: [1], //first column 
                orderable: false, //set not orderable
                className: "dt-center"
            },
            {
                targets: [2], //first column 
                orderable: false, //set not orderable
                className: "dt-center"
            },
            {
                targets: [-1], //last column
                orderable: false, //set not orderable
                className: "actions dt-center"
            }
        ], "<?php echo site_url('Cms_api/get_cond_as/' . $cond_id) ?>");

    tblInOut = initTable("#tbl_inout",
        [{
                targets: [0], //first column 
                orderable: true, //set not orderable
                className: "dt-center"
            },
            {
                targets: [1], //first column 
                orderable: false, //set not orderable
                className: "dt-center"
            },
            {
                targets: [2], //first column 
                orderable: false, //set not orderable
                className: "dt-center"
            },
            {
                targets: [-1], //last column
                orderable: false, //set not orderable
                className: "actions dt-center"
            }
        ], "<?php echo site_url('Cms_api/get_cond_inout/' . $cond_id) ?>");

    tblPort = initTable("#tbl_ports",
        [{
                targets: [0], //first column 
                orderable: true, //set not orderable
                className: "dt-center"
            },
            {
                targets: [1], //first column 
                orderable: false, //set not orderable
                className: "dt-center"
            },
            {
                targets: [2], //first column 
                orderable: false, //set not orderable
                className: "dt-center"
            },
            {
                targets: [-1], //last column
                orderable: false, //set not orderable
                className: "actions dt-center"
            }
        ], "<?php echo site_url('Cms_api/get_cond_ports/' . $cond_id) ?>");

    tblIcmp = initTable("#tbl_icmp",
        [{
                targets: [0], //first column 
                orderable: true, //set not orderable
                className: "dt-center"
            },
            {
                targets: [1], //first column 
                orderable: false, //set not orderable
                className: "dt-center"
            },
            {
                targets: [2], //first column 
                orderable: false, //set not orderable
                className: "dt-center"
            },
            {
                targets: [-1], //last column
                orderable: false, //set not orderable
                className: "actions dt-center"
            }
        ], "<?php echo site_url('Cms_api/get_cond_icmp/' . $cond_id) ?>");

    tblTcpFlag = initTable("#tbl_tcp_flag",
        [{
                targets: [0], //first column 
                orderable: true, //set not orderable
                className: "dt-center"
            },
            {
                targets: [1], //first column 
                orderable: false, //set not orderable
                className: "dt-center"
            },
            {
                targets: [-1], //last column
                orderable: false, //set not orderable
                className: "actions dt-center"
            }
        ], "<?php echo site_url('Cms_api/get_cond_tcp_flags/' . $cond_id) ?>");


    tblFwdStatus = initTable("#tbl_fwd_status",
        [{
                targets: [0], //first column 
                orderable: true, //set not orderable
                className: "dt-center"
            },
            {
                targets: [1], //first column 
                orderable: false, //set not orderable
                className: "dt-center"
            },
            {
                targets: [-1], //last column
                orderable: false, //set not orderable
                className: "actions dt-center"
            }
        ], "<?php echo site_url('Cms_api/get_cond_fwd_status/' . $cond_id) ?>");


    tblRouter = initTable("#tbl_router",
        [{
                targets: [0], //first column 
                orderable: true, //set not orderable
                className: "dt-center"
            },
            {
                targets: [1], //first column 
                orderable: false, //set not orderable
                className: "dt-center"
            },
            {
                targets: [2], //first column 
                orderable: false, //set not orderable
                className: "dt-center"
            },
            {
                targets: [-1], //last column
                orderable: false, //set not orderable
                className: "actions dt-center"
            }
        ], "<?php echo site_url('Cms_api/get_cond_routes/' . $cond_id) ?>");

    tblSubNet = initTable("#tbl_subnet",
        [{
                targets: [0], //first column 
                orderable: true, //set not orderable
                className: "dt-center"
            },
            {
                targets: [1], //first column 
                orderable: false, //set not orderable
                className: "dt-center"
            },
            {
                targets: [2], //first column 
                orderable: false, //set not orderable
                className: "dt-center"
            },
            {
                targets: [-1], //last column
                orderable: false, //set not orderable
                className: "actions dt-center"
            }
        ], "<?php echo site_url('Cms_api/get_cond_subnets/' . $cond_id) ?>");

    function addVersion() {
        var e = document.getElementById("protocol_version");
        var val = e.options[e.selectedIndex].value;
        $.post("<?php echo site_url('Cms_api/add_cond_version') ?>", {
            condId: condId,
            verId: val
        }, function(data) {
            if (data == '1')
                tblVersion.ajax.reload();
        });
    }

    function RemoveVersion(_id) {
        $.post("<?php echo site_url('Cms_api/remove_cond_version') ?>", {
            condId: condId,
            Id: _id
        }, function(data) {
            if (data == '1')
                tblVersion.ajax.reload();
        });
    }

    function addProtocol() {
        var e = document.getElementById("protocol_id");
        var val = e.options[e.selectedIndex].value;
        $.post("<?php echo site_url('Cms_api/add_cond_protocol') ?>", {
            condId: condId,
            protoId: val
        }, function(data) {
            if (data == '1')
                tblProtocol.ajax.reload();
        });
    }

    function RemoveProtocol(_id) {
        $.post("<?php echo site_url('Cms_api/remove_cond_protocol') ?>", {
            condId: condId,
            Id: _id
        }, function(data) {
            if (data == '1')
                tblProtocol.ajax.reload();
        });
    }

    function addIP() {
        var ip = document.getElementById("ip_addr").value;
        if (ip == "") return;

        var descr = document.getElementById("ip_descr").value;

        var e = document.getElementById("ip_from");
        var val = e.options[e.selectedIndex].value;
        $.post("<?php echo site_url('Cms_api/add_cond_ip') ?>", {
            condId: condId,
            ip: ip,
            op: val,
            descr: descr
        }, function(data) {
            if (data == '1')
                tblIP.ajax.reload();
        });
    }

    function RemoveIP(_id) {
        $.post("<?php echo site_url('Cms_api/remove_cond_ip') ?>", {
            condId: condId,
            Id: _id
        }, function(data) {
            if (data == '1')
                tblIP.ajax.reload();
        });
    }

    function addAS() {
        var asNum = document.getElementById("as_num").value;
        if (asNum == "") return;

        var descr = document.getElementById("as_descr").value;

        var e = document.getElementById("as_from");
        var val = e.options[e.selectedIndex].value;
        $.post("<?php echo site_url('Cms_api/add_cond_as') ?>", {
            condId: condId,
            asNum: asNum,
            op: val,
            descr: descr
        }, function(data) {
            if (data == '1')
                tblAS.ajax.reload();
        });
    }

    function RemoveAs(_id) {
        $.post("<?php echo site_url('Cms_api/remove_cond_as') ?>", {
            condId: condId,
            Id: _id
        }, function(data) {
            if (data == '1')
                tblAS.ajax.reload();
        });
    }


    function addInOut() {
        var inoutNum = document.getElementById("inout_num").value;
        if (inoutNum == "") return;

        var descr = document.getElementById("inout_descr").value;

        var e = document.getElementById("inout_from");
        var val = e.options[e.selectedIndex].value;
        $.post("<?php echo site_url('Cms_api/add_cond_inout') ?>", {
            condId: condId,
            inoutNum: inoutNum,
            op: val,
            descr: descr
        }, function(data) {
            if (data == '1')
                tblInOut.ajax.reload();
        });
    }

    function RemoveInOut(_id) {
        $.post("<?php echo site_url('Cms_api/remove_cond_inout') ?>", {
            condId: condId,
            Id: _id
        }, function(data) {
            if (data == '1')
                tblInOut.ajax.reload();
        });
    }

    function addPort() {
        var port = document.getElementById("port").value;
        if (port == 0 || port == "") return;

        var descr = document.getElementById("port_descr").value;

        var e = document.getElementById("port_from");
        var val = e.options[e.selectedIndex].value;
        $.post("<?php echo site_url('Cms_api/add_cond_port') ?>", {
            condId: condId,
            port: port,
            op: val,
            descr: descr
        }, function(data) {
            if (data == '1')
                tblPort.ajax.reload();
        });
    }

    function RemovePort(_id) {
        $.post("<?php echo site_url('Cms_api/remove_cond_port') ?>", {
            condId: condId,
            Id: _id
        }, function(data) {
            if (data == '1')
                tblPort.ajax.reload();
        });
    }

    function addIcmp() {
        var code = document.getElementById("icmp_code").value;
        var descr = document.getElementById("icmp_descr").value;

        var e = document.getElementById("icmp_type");
        var typeId = e.options[e.selectedIndex].value;
        $.post("<?php echo site_url('Cms_api/add_cond_icmp') ?>", {
            condId: condId,
            typeId: typeId,
            code: code,
            descr: descr
        }, function(data) {
            if (data == '1')
                tblIcmp.ajax.reload();
        });
    }

    function RemoveIcmp(_id) {
        $.post("<?php echo site_url('Cms_api/remove_cond_icmp') ?>", {
            condId: condId,
            Id: _id
        }, function(data) {
            if (data == '1')
                tblIcmp.ajax.reload();
        });
    }

    function addTcpFlag() {
        var e = document.getElementById("tcp_flag");
        var flagVal = e.options[e.selectedIndex].value;
        $.post("<?php echo site_url('Cms_api/add_tcp_flag') ?>", {
            condId: condId,
            flagVal: flagVal
        }, function(data) {
            if (data == '1')
                tblTcpFlag.ajax.reload();
        });
    }

    function RemoveTcpFlag(_id) {
        $.post("<?php echo site_url('Cms_api/remove_tcp_flag') ?>", {
            condId: condId,
            Id: _id
        }, function(data) {
            if (data == '1')
                tblTcpFlag.ajax.reload();
        });
    }

    function addFwdStatus() {
        var e = document.getElementById("fwd_status");
        var status = e.options[e.selectedIndex].value;
        $.post("<?php echo site_url('Cms_api/add_fwd_status') ?>", {
            condId: condId,
            status: status
        }, function(data) {
            if (data == '1')
                tblFwdStatus.ajax.reload();
        });
    }

    function RemoveFwdStatus(_id) {
        $.post("<?php echo site_url('Cms_api/remove_fwd_status') ?>", {
            condId: condId,
            Id: _id
        }, function(data) {
            if (data == '1')
                tblFwdStatus.ajax.reload();
        });
    }



    function addRouter() {
        var e = document.getElementById("router_id");
        var routerId = e.options[e.selectedIndex].value;
        $.post("<?php echo site_url('Cms_api/add_cond_router') ?>", {
            condId: condId,
            routerId: routerId
        }, function(data) {
            if (data == '1')
                tblRouter.ajax.reload();
        });
    }

    function RemoveRouter(_id) {
        $.post("<?php echo site_url('Cms_api/remove_cond_router') ?>", {
            condId: condId,
            Id: _id
        }, function(data) {
            if (data == '1')
                tblRouter.ajax.reload();
        });
    }


    function addSubNet() {
        var subnet = document.getElementById("subnet").value;
        var mask = document.getElementById("subnet_mask").value;
        var descr = document.getElementById("subnet_descr").value;
        var e = document.getElementById("subnet_from");
        var val = e.options[e.selectedIndex].value;


        $.post("<?php echo site_url('Cms_api/add_cond_subnet') ?>", {
            condId: condId,
            subnet: subnet,
            mask: mask,
            op: val,
            descr: descr,
        }, function(data) {
            if (data == '1')
                tblSubNet.ajax.reload();
        });
    }

    function RemoveSubNet(_id) {
        $.post("<?php echo site_url('Cms_api/remove_cond_subnet') ?>", {
            condId: condId,
            Id: _id
        }, function(data) {
            if (data == '1')
                tblSubNet.ajax.reload();
        });
    }
</script>
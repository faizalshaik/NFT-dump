    <!-- ============================================================== -->
    <!-- Start right Content here -->
    <!-- ============================================================== -->
    <div class="content-page">
        <!-- Start content -->
        <div class="content">
            <div class="container">
                <!-- Page-Title -->
                <div class="row">
                    <div class="col-sm-6">
                        <h4 class="page-title">View Statics</h4>
                        <ol class="breadcrumb"> </ol>
                    </div>
                </div>

                <div class="row">
                    <div class="col-sm-12">
                        <div class="card-box table-responsive">                            
                            <table id="datatable-match" class="table table-striped table-bordered">
                                <thead>
                                    <tr>
                                        <th>Collector</th>
                                        <th>Filter</th>
                                        <th>Prot</th>
                                        <th>TOS</th>
                                        <th>Forward</th>
                                        <th>Tcp Flags</th>
                                        <th>SrcIP</th>
                                        <th>SrcPort</th>
                                        <th>DstIP</th>
                                        <th>DstPort</th>
                                        <th>In Pkts</th>
                                        <th>Out Pkts</th>
                                        <th>In Bytes</th>
                                        <th>Out Bytes</th>
                                        <th>Router</th>
                                        <th>SrcAS</th>
                                        <th>DstAS</th>
                                        <th>IN</th>
                                        <th>OUT</th>
                                        <th>Start</th>
                                        <th>Last</th>
                                        <!-- <th>Duration</th> -->
                                        <th>Updated</th>
                                    </tr>
                                </thead>
                                <tbody>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div> <!-- container -->
        </div> <!-- content -->
    </div> <!-- content-page -->
    </div>
    <!-- END wrapper -->
    <script type="text/javascript">
        var tableMatch;
        var tableName = "<?php echo $table; ?>";

        var $dom = {
            Id: $("#Id"),
            name: $("#name"),
            val: $("#val"),
            descr: $("#descr"),
        }

        function clearData() {
            $dom.Id.val("");
            $dom.name.val("");
            $dom.val.val("");
            $dom.descr.val("");
        }

        function Edit(_idx) {
            $.ajax({
                url: "<?php echo site_url('Cms_api/getDataById') ?>",
                data: {
                    Id: _idx,
                    tbl_Name: tableName
                },
                type: "POST",
                dataType: "JSON",
                success: function(data) {
                    $dom.Id.val(data.Id);
                    $dom.name.val(data.name);
                    $dom.val.val(data.version);
                    $dom.descr.val(data.descr);
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    swal("Error!", "", "error");
                }
            });
        }

        function Remove(_idx) {
            swal({
                title: "Are you sure?",
                text: "You will not be able to recover this user information!",
                type: "error",
                showCancelButton: true,
                cancelButtonClass: 'btn-white btn-md waves-effect',
                confirmButtonClass: 'btn-danger btn-md waves-effect waves-light',
                confirmButtonText: 'Remove',
                closeOnConfirm: false
            }, function(isConfirm) {
                if (isConfirm) {
                    $.ajax({
                        url: "<?php echo site_url('Cms_api/delData') ?>",
                        data: {
                            Id: _idx,
                            tbl_Name: tableName
                        },
                        type: "POST",
                        dataType: "JSON",
                        success: function(data) {
                            swal("Remove!", "", "success");
                            tableMatch.ajax.reload();
                        },
                        error: function(jqXHR, textStatus, errorThrown) {
                            swal("Error!", "", "error");
                        }
                    });
                }
            });
        }



        var handleDataTableButtonsMatch = function() {
                tableMatch = $("#datatable-match").DataTable({
                    dom: "lfBrtip",
                    buttons: [{
                        extend: "copy",
                        className: "btn-sm"
                    }, {
                        extend: "csv",
                        className: "btn-sm"
                    }, {
                        extend: "excel",
                        className: "btn-sm"
                    }, {
                        extend: "pdf",
                        className: "btn-sm"
                    }, {
                        extend: "print",
                        className: "btn-sm"
                    }],
                    responsive: !0,
                    processing: true,
                    serverSide: true,
                    sPaginationType: "full_numbers",
                    language: {
                        paginate: {
                            next: '<i class="fa fa-angle-right"></i>',
                            previous: '<i class="fa fa-angle-left"></i>',
                            first: '<i class="fa fa-angle-double-left"></i>',
                            last: '<i class="fa fa-angle-double-right"></i>'
                        }
                    },
                    //Set column definition initialisation properties.
                    columnDefs: [{
                            targets: [0], //first column 
                            orderable: false, //set not orderable
                            className: "dt-center"
                        },
                        {
                            targets: [1], //first column 
                            orderable: false, //set not orderable
                            className: "dt-center"
                        },
                        {
                            targets: [2], //first column 
                            orderable: false, //set not orderable
                            className: "dt-center"
                        },
                        {
                            targets: [3], //first column 
                            orderable: false, //set not orderable
                            className: "dt-center"
                        },
                        {
                            targets: [4], //first column 
                            orderable: false, //set not orderable
                            className: "dt-center"
                        },
                        {
                            targets: [5], //first column 
                            orderable: false, //set not orderable
                            className: "dt-center"
                        },{
                            targets: [6], //first column 
                            orderable: false, //set not orderable
                            className: "dt-center"
                        },
                        {
                            targets: [7], //first column 
                            orderable: false, //set not orderable
                            className: "dt-center"
                        },
                        {
                            targets: [8], //first column 
                            orderable: false, //set not orderable
                            className: "dt-center"
                        },{
                            targets: [9], //first column 
                            orderable: false, //set not orderable
                            className: "dt-center"
                        },
                        {
                            targets: [10], //first column 
                            orderable: false, //set not orderable
                            className: "dt-center"
                        },
                        {
                            targets: [11], //first column 
                            orderable: false, //set not orderable
                            className: "dt-center"
                        }    ,
                        {
                            targets: [12], //first column 
                            orderable: false, //set not orderable
                            className: "dt-center"
                        }                      
                    ],
                    ajax: {
                        url: "<?php echo site_url('Cms_api/get_statics') ?>",
                        type: "POST",
                    },
                })
            },
            TableManageButtonsMatch = function() {
                return {
                    init: function() {
                        handleDataTableButtonsMatch()
                    }
                }
            }();
        TableManageButtonsMatch.init();
    </script>
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Cms_api extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		date_default_timezone_set('America/Chicago');
				
		$this->load->model('User_model');
		$this->load->model('Base_model');
		$this->load->model('Condition_model');
		$this->load->model('Nfcapd_model');			

		$this->load->model('Protocol_model');
		$this->load->model('CondProtocols_model');
		$this->load->model('CondIPs_model');		
		$this->load->model('CondPorts_model');		
		$this->load->model('CondVersions_model');		
		$this->load->model('Version_model');	

		$this->load->model('IcmpType_model');			
		$this->load->model('CondIcmp_model');			

		$this->load->model('Router_model');			
		$this->load->model('CondRouters_model');
		$this->load->model('CondAs_model');
		$this->load->model('InOut_model');

		$this->load->model('TcpFlag_model');
		$this->load->model('CondTcpFlags_model');

		$this->load->model('FwdStatus_model');	
		$this->load->model('CondFwdStatus_model');		
		$this->load->model('CondSubNets_model');		

		$this->load->model('Statics_model');	

			
	}

	public function reply($status, $message, $data)
	{
		$result = array('status'=>$status, 'message'=>$message, 'data'=>$data);
		echo json_encode($result);
	}	
	public function ajaxDel() {
		if($this->logonCheck()) {
			global $MYSQL;
			$Id = $this->input->post('Id');
			$tbl_Name = $this->input->post('tbl_Name');
			if($tbl_Name !='') {
				$conAry = array('Id' => $Id);
				$updateAry = array('isdeleted'=>'1');
				$this->Base_model->updateData($tbl_Name, $conAry, $updateAry);
				echo json_encode(array("status" => TRUE));	
			} else {
				echo json_encode(array("status" => FALSE));	
			}
		}
	}
	public function delUser() {
		if($this->logonCheck()) {
			global $MYSQL;
			$Id = $this->input->post('Id');
			$tbl_Name = $this->input->post('tbl_Name');
			if($tbl_Name !='') {
				$this->Base_model->deleteByField($tbl_Name, "Id", $Id);
				echo json_encode(array("status" => TRUE));	
			} else {
				echo json_encode(array("status" => FALSE));	
			}
		}
	}
	public function getDataById() {
		$this->logonCheck();

		$Id = $this->input->post("Id");
		$tableName = $this->input->post("tbl_Name");
		$ret = $this->Base_model->getRow($tableName, array('Id'=>$Id));
		echo json_encode($ret);
	}
	public function delData()
	{
		$this->logonCheck();
		$Id = $this->input->post("Id");
		$tableName = $this->input->post("tbl_Name");
		$ret = $this->Base_model->deleteRow($tableName, array('Id'=>$Id));
		echo "1";
	}

	public function get_conditions() {
		$this->logonCheck();
		$conds = $this->Condition_model->getDatas(null);

		$data = array();
		foreach($conds as $cond)
		{
			$row = array();
			$row[] = $cond->descr;
			$row[] = "";
			$strAction = '<a href="javascript:void(0)" class="on-default edit-row" '.
				'onclick="EditCondition('.$cond->Id.')" title="Edit" ><i class="fa fa-pencil"></i></a>'.
				'<a href="javascript:void(0)" class="on-default remove-row" '.
				'onclick="RemoveCondition('.$cond->Id.')" title="Remove" ><i class="fa fa-trash-o"></i></a>'.
				'<a href="javascript:void(0)" class="on-default remove-row" '.
				'onclick="ViewCondition('.$cond->Id.')" title="View" ><i class="fa fa-eye"></i></a>';
			$row[] = $strAction;
			$data[] = $row;
		}
		$output = array(
			"draw" => null,
			"recordsTotal" => count($data),
			"recordsFiltered" => count($data),
			"data" => $data,
		);
		//output to json format
		echo json_encode($output);
	}
	public function edit_condition_fasst()
	{
		$this->logonCheck();		
		$Id = $this->input->post('conditionId');
		$descr = $this->input->post('descr');

		$data = array('descr'=>$descr);
		if($Id=="")
		{
			$this->Condition_model->insertData($data);
		}
		else
		{
			$this->Condition_model->updateData(array('Id'=>$Id), $data);
		}
		redirect('Cms/conditions', 'refresh');
	}


	public function get_nfcapds()
	{
		$this->logonCheck();
		$nfcapds = $this->Nfcapd_model->getDatas(null);

		$data = array();
		foreach($nfcapds as $nfcapd)
		{
			$row = array();
			$row[] = $nfcapd->Id;
			$row[] = $nfcapd->descr;

			$cond = $this->Condition_model->getRow(array('Id'=>$nfcapd->cond_id));			
			if($cond)
				$row[] = $cond->descr;
			else
				$row[] = "";

			$strAction = '<a href="javascript:void(0)" class="on-default edit-row" '.
				'onclick="EditNfcapd('.$nfcapd->Id.')" title="Edit" ><i class="fa fa-pencil"></i></a>'.
				'<a href="javascript:void(0)" class="on-default remove-row" '.
				'onclick="RemoveNfcapd('.$nfcapd->Id.')" title="Remove" ><i class="fa fa-trash-o"></i></a>';

			if($cond!=null)
				$strAction .='<a href="javascript:void(0)" class="on-default remove-row" '.
					'onclick="ViewCondition('.$nfcapd->cond_id.')" title="Condition" ><i class="fa fa-eye"></i></a>';

			$row[] = $strAction;
			$data[] = $row;
		}
		$output = array(
			"draw" => null,
			"recordsTotal" => count($data),
			"recordsFiltered" => count($data),
			"data" => $data,
		);
		//output to json format
		echo json_encode($output);
	}

	public function edit_nfcapd()
	{
		$this->logonCheck();		
		$Id = $this->input->post('nfcapdId');
		$cond_id = $this->input->post('cond_id');
		$descr = $this->input->post('descr');

		$data = array('descr'=>$descr, 'cond_id'=>$cond_id);
		if($Id=="")
		{
			$this->Nfcapd_model->insertData($data);
		}
		else
		{
			$this->Nfcapd_model->updateData(array('Id'=>$Id), $data);
		}
		redirect('Cms/nfcapds', 'refresh');
	}

	public function get_versions()
	{
		$this->logonCheck();
		$datas = $this->Version_model->getDatas(null);

		$resultData = array();
		foreach($datas as $data)
		{
			$row = array();
			$row[] = $data->name;
			$row[] = $data->version;
			$row[] = $data->descr;
			$strAction = '<a href="javascript:void(0)" class="on-default edit-row" '.
				'onclick="Edit('.$data->Id.')" title="Edit" ><i class="fa fa-pencil"></i></a>'.
				'<a href="javascript:void(0)" class="on-default remove-row" '.
				'onclick="Remove('.$data->Id.')" title="Remove" ><i class="fa fa-trash-o"></i></a>';
			$row[] = $strAction;
			$resultData[] = $row;
		}
		$output = array(
			"draw" => null,
			"recordsTotal" => count($resultData),
			"recordsFiltered" => count($resultData),
			"data" => $resultData,
		);
		echo json_encode($output);		
	}

	public function edit_version()
	{
		$this->logonCheck();		
		$Id = $this->input->post('Id');
		$name = $this->input->post('name');
		$val = $this->input->post('val');
		$descr = $this->input->post('descr');

		$data = array('name'=>$name, 'version'=>$val, 'descr'=>$descr);
		if($Id=="")
		{
			$this->Version_model->insertData($data);
		}
		else
		{
			$this->Version_model->updateData(array('Id'=>$Id), $data);
		}
		echo "1";
	}

	public function get_protocols()
	{
		$this->logonCheck();
		$datas = $this->Protocol_model->getDatas(null);

		$resultData = array();
		foreach($datas as $data)
		{
			$row = array();
			$row[] = $data->name;
			$row[] = $data->value;
			$row[] = $data->descr;
			$strAction = '<a href="javascript:void(0)" class="on-default edit-row" '.
				'onclick="Edit('.$data->Id.')" title="Edit" ><i class="fa fa-pencil"></i></a>'.
				'<a href="javascript:void(0)" class="on-default remove-row" '.
				'onclick="Remove('.$data->Id.')" title="Remove" ><i class="fa fa-trash-o"></i></a>';
			$row[] = $strAction;
			$resultData[] = $row;
		}
		$output = array(
			"draw" => null,
			"recordsTotal" => count($resultData),
			"recordsFiltered" => count($resultData),
			"data" => $resultData,
		);
		echo json_encode($output);		
	}

	public function edit_protocol()
	{
		$this->logonCheck();		
		$Id = $this->input->post('Id');
		$name = $this->input->post('name');
		$val = $this->input->post('val');
		$descr = $this->input->post('descr');

		$data = array('name'=>$name, 'value'=>$val, 'descr'=>$descr);
		if($Id=="")
		{
			$this->Protocol_model->insertData($data);
		}
		else
		{
			$this->Protocol_model->updateData(array('Id'=>$Id), $data);
		}
		echo "1";
	}


	public function get_icmp_types()
	{
		$this->logonCheck();
		$datas = $this->IcmpType_model->getDatas(null);

		$resultData = array();
		foreach($datas as $data)
		{
			$row = array();
			$row[] = $data->name;
			$row[] = $data->value;
			$row[] = $data->descr;
			$strAction = '<a href="javascript:void(0)" class="on-default edit-row" '.
				'onclick="Edit('.$data->Id.')" title="Edit" ><i class="fa fa-pencil"></i></a>'.
				'<a href="javascript:void(0)" class="on-default remove-row" '.
				'onclick="Remove('.$data->Id.')" title="Remove" ><i class="fa fa-trash-o"></i></a>';
			$row[] = $strAction;
			$resultData[] = $row;
		}
		$output = array(
			"draw" => null,
			"recordsTotal" => count($resultData),
			"recordsFiltered" => count($resultData),
			"data" => $resultData,
		);
		echo json_encode($output);		
	}

	public function edit_icmp_type()
	{
		$this->logonCheck();		
		$Id = $this->input->post('Id');
		$name = $this->input->post('name');
		$val = $this->input->post('val');
		$descr = $this->input->post('descr');

		$data = array('name'=>$name, 'value'=>$val, 'descr'=>$descr);
		if($Id=="")
		{
			$this->IcmpType_model->insertData($data);
		}
		else
		{
			$this->IcmpType_model->updateData(array('Id'=>$Id), $data);
		}
		echo "1";
	}


	public function get_tcp_flags()
	{
		$this->logonCheck();
		$datas = $this->TcpFlag_model->getDatas(null);

		$resultData = array();
		foreach($datas as $data)
		{
			$row = array();
			$row[] = $data->value;
			$row[] = $data->descr;
			$strAction = '<a href="javascript:void(0)" class="on-default edit-row" '.
				'onclick="Edit('.$data->Id.')" title="Edit" ><i class="fa fa-pencil"></i></a>'.
				'<a href="javascript:void(0)" class="on-default remove-row" '.
				'onclick="Remove('.$data->Id.')" title="Remove" ><i class="fa fa-trash-o"></i></a>';
			$row[] = $strAction;
			$resultData[] = $row;
		}
		$output = array(
			"draw" => null,
			"recordsTotal" => count($resultData),
			"recordsFiltered" => count($resultData),
			"data" => $resultData,
		);
		echo json_encode($output);		
	}

	public function edit_tcp_flags()
	{
		$this->logonCheck();		
		$Id = $this->input->post('Id');
		$val = $this->input->post('val');
		$descr = $this->input->post('descr');

		$data = array('value'=>$val, 'descr'=>$descr);
		if($Id=="")
		{
			$this->TcpFlag_model->insertData($data);
		}
		else
		{
			$this->TcpFlag_model->updateData(array('Id'=>$Id), $data);
		}
		echo "1";
	}

	public function get_fwd_status()
	{
		$this->logonCheck();
		$datas = $this->FwdStatus_model->getDatas(null);

		$resultData = array();
		foreach($datas as $data)
		{
			$row = array();
			$row[] = $data->value;
			$row[] = $data->descr;
			$strAction = '<a href="javascript:void(0)" class="on-default edit-row" '.
				'onclick="Edit('.$data->Id.')" title="Edit" ><i class="fa fa-pencil"></i></a>'.
				'<a href="javascript:void(0)" class="on-default remove-row" '.
				'onclick="Remove('.$data->Id.')" title="Remove" ><i class="fa fa-trash-o"></i></a>';
			$row[] = $strAction;
			$resultData[] = $row;
		}
		$output = array(
			"draw" => null,
			"recordsTotal" => count($resultData),
			"recordsFiltered" => count($resultData),
			"data" => $resultData,
		);
		echo json_encode($output);		
	}

	public function edit_fwd_status()
	{
		$this->logonCheck();		
		$Id = $this->input->post('Id');
		$val = $this->input->post('val');
		$descr = $this->input->post('descr');

		$data = array('value'=>$val, 'descr'=>$descr);
		if($Id=="")
		{
			$this->FwdStatus_model->insertData($data);
		}
		else
		{
			$this->FwdStatus_model->updateData(array('Id'=>$Id), $data);
		}
		echo "1";
	}	

	public function get_routers()
	{
		$this->logonCheck();
		$datas = $this->Router_model->getDatas(null);

		$resultData = array();
		foreach($datas as $data)
		{
			$row = array();
			$row[] = $data->ip;
			$row[] = $data->descr;
			$row[] = $data->detail;
			$strAction = '<a href="javascript:void(0)" class="on-default edit-row" '.
				'onclick="Edit('.$data->Id.')" title="Edit" ><i class="fa fa-pencil"></i></a>'.
				'<a href="javascript:void(0)" class="on-default remove-row" '.
				'onclick="Remove('.$data->Id.')" title="Remove" ><i class="fa fa-trash-o"></i></a>';
			$row[] = $strAction;
			$resultData[] = $row;
		}
		$output = array(
			"draw" => null,
			"recordsTotal" => count($resultData),
			"recordsFiltered" => count($resultData),
			"data" => $resultData,
		);
		echo json_encode($output);		
	}

	public function edit_router()
	{
		$this->logonCheck();		
		$Id = $this->input->post('Id');
		$ip = $this->input->post('ip');
		$descr = $this->input->post('descr');
		$detail = $this->input->post('detail');		

		$data = array('ip'=>$ip, 'descr'=>$descr, 'detail'=>$detail);
		if($Id=="")
		{
			$this->Router_model->insertData($data);
		}
		else
		{
			$this->Router_model->updateData(array('Id'=>$Id), $data);
		}
		echo "1";
	}

	public function get_cond_versions($condId)
	{
		$this->logonCheck();
		$datas = $this->CondVersions_model->getDatas(array('cond_id'=>$condId));

		$resultData = array();
		foreach($datas as $data)
		{
			$rowData = $this->Version_model->getRow(array('Id'=>$data->version_id));
			if($rowData == null) continue;

			$row = array();
			$row[] = $rowData->name;
			$row[] = $rowData->descr;
			$strAction = '<a href="javascript:void(0)" class="on-default remove-row" '.
				'onclick="RemoveVersion('.$data->Id.')" title="Remove" ><i class="fa fa-trash-o"></i></a>';
			$row[] = $strAction;
			$resultData[] = $row;
		}
		$output = array(
			"draw" => null,
			"recordsTotal" => count($resultData),
			"recordsFiltered" => count($resultData),
			"data" => $resultData,
		);
		echo json_encode($output);
	}

	public function get_cond_protocols($condId)
	{
		$this->logonCheck();
		$datas = $this->CondProtocols_model->getDatas(array('cond_id'=>$condId));

		$resultData = array();
		foreach($datas as $data)
		{
			$rowData = $this->Protocol_model->getRow(array('Id'=>$data->protocol_id));
			if($rowData == null) continue;

			$row = array();
			$row[] = $rowData->name;
			$row[] = $rowData->descr;
			$strAction = '<a href="javascript:void(0)" class="on-default remove-row" '.
				'onclick="RemoveProtocol('.$data->Id.')" title="Remove" ><i class="fa fa-trash-o"></i></a>';
			$row[] = $strAction;
			$resultData[] = $row;
		}
		$output = array(
			"draw" => null,
			"recordsTotal" => count($resultData),
			"recordsFiltered" => count($resultData),
			"data" => $resultData,
		);
		echo json_encode($output);
	}	

	public function get_cond_ips($condId)
	{
		$this->logonCheck();
		$datas = $this->CondIPs_model->getDatas(array('cond_id'=>$condId), 'op');

		$resultData = array();
		foreach($datas as $data)
		{
			$row = array();
			$row[] = $data->ip;
			$row[] = $data->op;
			$row[] = $data->descr;
			$strAction = '<a href="javascript:void(0)" class="on-default remove-row" '.
				'onclick="RemoveIP('.$data->Id.')" title="Remove" ><i class="fa fa-trash-o"></i></a>';
			$row[] = $strAction;
			$resultData[] = $row;
		}
		$output = array(
			"draw" => null,
			"recordsTotal" => count($resultData),
			"recordsFiltered" => count($resultData),
			"data" => $resultData,
		);
		echo json_encode($output);
	}	

	public function get_cond_as($condId)
	{
		$this->logonCheck();
		$datas = $this->CondAs_model->getDatas(array('cond_id'=>$condId), 'op');

		$resultData = array();
		foreach($datas as $data)
		{
			$row = array();
			$row[] = $data->as_num;
			$row[] = $data->op;
			$row[] = $data->descr;
			$strAction = '<a href="javascript:void(0)" class="on-default remove-row" '.
				'onclick="RemoveAs('.$data->Id.')" title="Remove" ><i class="fa fa-trash-o"></i></a>';
			$row[] = $strAction;
			$resultData[] = $row;
		}
		$output = array(
			"draw" => null,
			"recordsTotal" => count($resultData),
			"recordsFiltered" => count($resultData),
			"data" => $resultData,
		);
		echo json_encode($output);
	}

	public function get_cond_inout($condId)
	{
		$this->logonCheck();
		$datas = $this->InOut_model->getDatas(array('cond_id'=>$condId), 'op');

		$resultData = array();
		foreach($datas as $data)
		{
			$row = array();
			$row[] = $data->inout_num;
			$row[] = $data->op;
			$row[] = $data->descr;
			$strAction = '<a href="javascript:void(0)" class="on-default remove-row" '.
				'onclick="RemoveInOut('.$data->Id.')" title="Remove" ><i class="fa fa-trash-o"></i></a>';
			$row[] = $strAction;
			$resultData[] = $row;
		}
		$output = array(
			"draw" => null,
			"recordsTotal" => count($resultData),
			"recordsFiltered" => count($resultData),
			"data" => $resultData,
		);
		echo json_encode($output);
	}


	public function get_cond_ports($condId)
	{
		$this->logonCheck();
		$datas = $this->CondPorts_model->getDatas(array('cond_id'=>$condId), 'op');

		$resultData = array();
		foreach($datas as $data)
		{
			$row = array();
			$row[] = $data->port;
			$row[] = $data->op;
			$row[] = $data->descr;
			$strAction = '<a href="javascript:void(0)" class="on-default remove-row" '.
				'onclick="RemovePort('.$data->Id.')" title="Remove" ><i class="fa fa-trash-o"></i></a>';
			$row[] = $strAction;
			$resultData[] = $row;
		}
		$output = array(
			"draw" => null,
			"recordsTotal" => count($resultData),
			"recordsFiltered" => count($resultData),
			"data" => $resultData,
		);
		echo json_encode($output);
	}	
	
	public function get_cond_subnets($condId)
	{
		$this->logonCheck();
		$datas = $this->CondSubNets_model->getDatas(array('cond_id'=>$condId), 'op');

		$resultData = array();
		foreach($datas as $data)
		{
			$row = array();
			$row[] = $data->ip;
			$row[] = $data->mask;
			$row[] = $data->op;
			$row[] = $data->descr;
			$strAction = '<a href="javascript:void(0)" class="on-default remove-row" '.
				'onclick="RemoveSubNet('.$data->Id.')" title="Remove" ><i class="fa fa-trash-o"></i></a>';
			$row[] = $strAction;
			$resultData[] = $row;
		}
		$output = array(
			"draw" => null,
			"recordsTotal" => count($resultData),
			"recordsFiltered" => count($resultData),
			"data" => $resultData,
		);
		echo json_encode($output);
	}			

	public function get_cond_icmp($condId)
	{
		$this->logonCheck();
		$datas = $this->CondIcmp_model->getDatas(array('cond_id'=>$condId));

		$resultData = array();
		foreach($datas as $data)
		{
			$rowData = $this->IcmpType_model->getRow(array('Id'=>$data->type_id));
			if($rowData == null) continue;

			$row = array();
			$row[] = $rowData->name;
			$row[] = $data->code;			
			$row[] = $data->descr;
			$strAction = '<a href="javascript:void(0)" class="on-default remove-row" '.
				'onclick="RemoveIcmp('.$data->Id.')" title="Remove" ><i class="fa fa-trash-o"></i></a>';
			$row[] = $strAction;
			$resultData[] = $row;
		}
		$output = array(
			"draw" => null,
			"recordsTotal" => count($resultData),
			"recordsFiltered" => count($resultData),
			"data" => $resultData,
		);
		echo json_encode($output);
	}

	public function get_cond_routes($condId)
	{

		$this->logonCheck();
		$datas = $this->CondRouters_model->getDatas(array('cond_id'=>$condId));

		$resultData = array();
		foreach($datas as $data)
		{
			$rowData = $this->Router_model->getRow(array('Id'=>$data->router_id));
			if($rowData == null) continue;

			$row = array();
			$row[] = $rowData->ip;
			$row[] = $rowData->descr;
			$row[] = $rowData->detail;
			$strAction = '<a href="javascript:void(0)" class="on-default remove-row" '.
				'onclick="RemoveRouter('.$data->Id.')" title="Remove" ><i class="fa fa-trash-o"></i></a>';
			$row[] = $strAction;
			$resultData[] = $row;
		}
		$output = array(
			"draw" => null,
			"recordsTotal" => count($resultData),
			"recordsFiltered" => count($resultData),
			"data" => $resultData,
		);
		echo json_encode($output);
	}	


	public function add_cond_version()
	{
		$this->logonCheck();
		$condId = $this->input->post('condId');
		$verId = $this->input->post('verId');

		$data = array('cond_id'=>$condId , 'version_id'=>$verId);

		$row = $this->CondVersions_model->getRow($data);
		if($row !=null) 
		{
			echo '0';
			return;
		} 
		$this->CondVersions_model->insertData($data);
		echo '1';
	}
	public function remove_cond_version()
	{
		$this->logonCheck();
		$condId = $this->input->post('condId');
		$Id = $this->input->post('Id');
		$data = array('cond_id'=>$condId , 'Id'=>$Id);
		$this->CondVersions_model->deleteRow($data);
		echo '1';
	}

	public function add_cond_protocol()
	{
		$this->logonCheck();
		$condId = $this->input->post('condId');
		$protoId = $this->input->post('protoId');

		$data = array('cond_id'=>$condId , 'protocol_id'=>$protoId);

		$row = $this->CondProtocols_model->getRow($data);
		if($row !=null) 
		{
			echo '0';
			return;
		} 
		$this->CondProtocols_model->insertData($data);
		echo '1';
	}
	public function remove_cond_protocol()
	{
		$this->logonCheck();
		$condId = $this->input->post('condId');
		$Id = $this->input->post('Id');
		$data = array('cond_id'=>$condId , 'Id'=>$Id);
		$this->CondProtocols_model->deleteRow($data);
		echo '1';
	}

	public function add_cond_ip()
	{
		$this->logonCheck();
		$condId = $this->input->post('condId');
		$ip = $this->input->post('ip');
		$op = $this->input->post('op');
		$descr = $this->input->post('descr');		

		$data = array('cond_id'=>$condId , 'ip'=>$ip, 'op'=>$op, 'descr'=>$descr);

		$row = $this->CondIPs_model->getRow($data);
		if($row !=null) 
		{
			echo '0';
			return;
		} 
		$this->CondIPs_model->insertData($data);
		echo '1';
	}
	public function remove_cond_ip()
	{
		$this->logonCheck();
		$condId = $this->input->post('condId');
		$Id = $this->input->post('Id');
		$data = array('cond_id'=>$condId , 'Id'=>$Id);
		$this->CondIPs_model->deleteRow($data);
		echo '1';
	}

	public function add_cond_as()
	{
		$this->logonCheck();
		$condId = $this->input->post('condId');
		$asNum = $this->input->post('asNum');
		$op = $this->input->post('op');
		$descr = $this->input->post('descr');		

		$data = array('cond_id'=>$condId , 'as_num'=>$asNum, 'op'=>$op, 'descr'=>$descr);

		$row = $this->CondAs_model->getRow($data);
		if($row !=null) 
		{
			echo '0';
			return;
		} 
		$this->CondAs_model->insertData($data);
		echo '1';
	}
	public function remove_cond_as()
	{
		$this->logonCheck();
		$condId = $this->input->post('condId');
		$Id = $this->input->post('Id');
		$data = array('cond_id'=>$condId , 'Id'=>$Id);
		$this->CondAs_model->deleteRow($data);
		echo '1';
	}	

	public function add_cond_inout()
	{
		$this->logonCheck();
		$condId = $this->input->post('condId');
		$inoutNum = $this->input->post('inoutNum');
		$op = $this->input->post('op');
		$descr = $this->input->post('descr');		

		$data = array('cond_id'=>$condId , 'inout_num'=>$inoutNum, 'op'=>$op, 'descr'=>$descr);

		$row = $this->InOut_model->getRow($data);
		if($row !=null) 
		{
			echo '0';
			return;
		} 
		$this->InOut_model->insertData($data);
		echo '1';
	}
	public function remove_cond_inout()
	{
		$this->logonCheck();
		$condId = $this->input->post('condId');
		$Id = $this->input->post('Id');
		$data = array('cond_id'=>$condId , 'Id'=>$Id);
		$this->InOut_model->deleteRow($data);
		echo '1';
	}		

	public function add_cond_port()
	{
		$this->logonCheck();
		$condId = $this->input->post('condId');
		$port = $this->input->post('port');
		$op = $this->input->post('op');
		$descr = $this->input->post('descr');		

		$data = array('cond_id'=>$condId , 'port'=>$port, 'op'=>$op, 'descr'=>$descr);

		$row = $this->CondPorts_model->getRow($data);
		if($row !=null) 
		{
			echo '0';
			return;
		} 
		$this->CondPorts_model->insertData($data);
		echo '1';
	}
	public function remove_cond_port()
	{
		$this->logonCheck();
		$condId = $this->input->post('condId');
		$Id = $this->input->post('Id');
		$data = array('cond_id'=>$condId , 'Id'=>$Id);
		$this->CondPorts_model->deleteRow($data);
		echo '1';
	}
	

	public function add_cond_subnet()
	{
		$this->logonCheck();
		$condId = $this->input->post('condId');
		$subnet = $this->input->post('subnet');
		$op = $this->input->post('op');
		$descr = $this->input->post('descr');		

		$data = array('cond_id'=>$condId , 'ip'=>$subnet, 'op'=>$op, 'descr'=>$descr);

		$row = $this->CondSubNets_model->getRow($data);
		if($row !=null) 
		{
			echo '0';
			return;
		} 
		$this->CondSubNets_model->insertData($data);
		echo '1';
	}
	public function remove_cond_subnet()
	{
		$this->logonCheck();
		$condId = $this->input->post('condId');
		$Id = $this->input->post('Id');
		$data = array('cond_id'=>$condId , 'Id'=>$Id);
		$this->CondSubNets_model->deleteRow($data);
		echo '1';
	}

	public function add_cond_icmp()
	{
		$this->logonCheck();
		$condId = $this->input->post('condId');
		$typeId = $this->input->post('typeId');
		$code = $this->input->post('code');
		$descr = $this->input->post('descr');		

		$data = array('cond_id'=>$condId , 'type_id'=>$typeId, 'code'=>$code, 'descr'=>$descr);

		$row = $this->CondIcmp_model->getRow($data);
		if($row !=null) 
		{
			echo '0';
			return;
		} 
		$this->CondIcmp_model->insertData($data);
		echo '1';
	}
	public function remove_cond_icmp()
	{
		$this->logonCheck();
		$condId = $this->input->post('condId');
		$Id = $this->input->post('Id');
		$data = array('cond_id'=>$condId , 'Id'=>$Id);
		$this->CondIcmp_model->deleteRow($data);
		echo '1';
	}


	public function get_cond_tcp_flags($condId)
	{
		$this->logonCheck();
		$datas = $this->CondTcpFlags_model->getDatas(array('cond_id'=>$condId));

		$resultData = array();
		foreach($datas as $data)
		{
			$rowData = $this->TcpFlag_model->getRow(array('value'=>$data->flag));
			if($rowData == null) continue;

			$row = array();
			$row[] = $rowData->value;
			$row[] = $rowData->descr;
			$strAction = '<a href="javascript:void(0)" class="on-default remove-row" '.
				'onclick="RemoveTcpFlag('.$data->Id.')" title="Remove" ><i class="fa fa-trash-o"></i></a>';
			$row[] = $strAction;
			$resultData[] = $row;
		}
		$output = array(
			"draw" => null,
			"recordsTotal" => count($resultData),
			"recordsFiltered" => count($resultData),
			"data" => $resultData,
		);
		echo json_encode($output);
	}	

	public function add_tcp_flag()
	{
		$this->logonCheck();
		$condId = $this->input->post('condId');
		$flagVal = $this->input->post('flagVal');
		$data = array('cond_id'=>$condId , 'flag'=>$flagVal);

		$row = $this->CondTcpFlags_model->getRow($data);
		if($row !=null) 
		{
			echo '0';
			return;
		} 
		$this->CondTcpFlags_model->insertData($data);
		echo '1';
	}
	public function remove_tcp_flag()
	{
		$this->logonCheck();
		$condId = $this->input->post('condId');
		$Id = $this->input->post('Id');
		$data = array('cond_id'=>$condId , 'Id'=>$Id);
		$this->CondTcpFlags_model->deleteRow($data);
		echo '1';
	}	

	public function get_cond_fwd_status($condId)
	{
		$this->logonCheck();
		$datas = $this->CondFwdStatus_model->getDatas(array('cond_id'=>$condId));

		$resultData = array();
		foreach($datas as $data)
		{
			$rowData = $this->FwdStatus_model->getRow(array('value'=>$data->status));
			if($rowData == null) continue;

			$row = array();
			$row[] = $rowData->value;
			$row[] = $rowData->descr;
			$strAction = '<a href="javascript:void(0)" class="on-default remove-row" '.
				'onclick="RemoveFwdStatus('.$data->Id.')" title="Remove" ><i class="fa fa-trash-o"></i></a>';
			$row[] = $strAction;
			$resultData[] = $row;
		}
		$output = array(
			"draw" => null,
			"recordsTotal" => count($resultData),
			"recordsFiltered" => count($resultData),
			"data" => $resultData,
		);
		echo json_encode($output);
	}	

	public function add_fwd_status()
	{
		$this->logonCheck();
		$condId = $this->input->post('condId');
		$status = $this->input->post('status');
		$data = array('cond_id'=>$condId , 'status'=>$status);

		$row = $this->CondFwdStatus_model->getRow($data);
		if($row !=null) 
		{
			echo '0';
			return;
		} 
		$this->CondFwdStatus_model->insertData($data);
		echo '1';
	}
	public function remove_fwd_status()
	{
		$this->logonCheck();
		$condId = $this->input->post('condId');
		$Id = $this->input->post('Id');
		$data = array('cond_id'=>$condId , 'Id'=>$Id);
		$this->CondFwdStatus_model->deleteRow($data);
		echo '1';
	}	


	public function add_cond_router()
	{
		$this->logonCheck();
		$condId = $this->input->post('condId');
		$routerId = $this->input->post('routerId');

		$data = array('cond_id'=>$condId , 'router_id'=>$routerId);

		$row = $this->CondRouters_model->getRow($data);
		if($row !=null) 
		{
			echo '0';
			return;
		} 
		$this->CondRouters_model->insertData($data);
		echo '1';
	}
	public function remove_cond_router()
	{
		$this->logonCheck();
		$condId = $this->input->post('condId');
		$Id = $this->input->post('Id');
		$data = array('cond_id'=>$condId , 'Id'=>$Id);
		$this->CondRouters_model->deleteRow($data);
		echo '1';
	}	


	public function getFilterCondition()
	{
		$_POST = json_decode(file_get_contents("php://input"), true); 
		$id = $_POST['nfcapd_id'];

		$capd = $this->Nfcapd_model->getRow(array('Id'=>$id));
		if($capd == null)
			return $this->reply(400, "nfcapd no exist", null);
		
		$cond_id = $capd->cond_id;
		$cond = $this->Condition_model->getRow(array('Id'=>$cond_id));
		if($cond == null)
			return $this->reply(400, "condition no exist", null);

		$condition = array();
		$condition['Id'] = $cond_id;
		$condition['options'] = $cond;


		//versions
		$versions = array();
		$vers = $this->CondVersions_model->getDatas(array('cond_id'=>$cond_id));
		foreach($vers as $ver)
		{
			$version = $this->Version_model->getRow(array('Id'=>$ver->version_id));
			if($version == null) continue;
			$versions[]= $version;
		}
		$condition['versions'] = $versions;
				
		//protos
		$protos = array();
		$datas = $this->CondProtocols_model->getDatas(array('cond_id'=>$cond_id));
		foreach($datas as $data)
		{
			$proto = $this->Protocol_model->getRow(array('Id'=>$data->protocol_id));
			if($proto == null) continue;
			$protos[]= $proto;
		}
		$condition['protos'] = $protos;

		//SA, DA
		$srcIPs = array(); 
		$dstIPs = array();
		$ips = $this->CondIPs_model->getDatas(array('cond_id'=>$cond_id));
		foreach($ips as $ip)
		{
			if($ip->op=="SRC")
				$srcIPs[]=$ip->ip;
			else
				$dstIPs[]=$ip->ip;
		}
		$condition['saddrs'] = $srcIPs;
		$condition['daddrs'] = $dstIPs;

		//ports
		$srcPorts = array(); 
		$dstPorts = array();
		$ports = $this->CondPorts_model->getDatas(array('cond_id'=>$cond_id));
		foreach($ports as $port)
		{
			if($port->op=="SRC")
				$srcPorts[]=$port->port;
			else
				$dstPorts[]=$port->port;
		}
		$condition['sports'] = $srcPorts;
		$condition['dports'] = $dstPorts;		

		//routers
		$routers = array();
		$datas = $this->CondRouters_model->getDatas(array('cond_id'=>$cond_id));
		foreach($datas as $data)
		{
			$router = $this->Router_model->getRow(array('Id'=>$data->router_id));
			if($router == null) continue;

			$routers[] = $router;
		}
		$condition['routers'] = $routers;

		//subnets
		$srcsubnets = array(); 
		$dstsubnets = array();
		$datas = $this->CondSubNets_model->getDatas(array('cond_id'=>$cond_id));
		foreach($datas as $data)
		{
			if($data->op=="SRC")
				$srcsubnets[]=array('ip'=>$data->ip, 'mask'=>$data->mask);
			else {
				$dstsubnets[]=$data;
			} 
		}
		$condition['src_subnets'] = $srcsubnets;
		$condition['dst_subnets'] = $dstsubnets;

		//SRCAS, DSTAS
		$srcASs = array(); 
		$dstASs = array();
		$ass = $this->CondAs_model->getDatas(array('cond_id'=>$cond_id));
		foreach($ass as $as)
		{
			if($as->op=="SRC")
				$srcASs[]=$as->as_num;
			else
				$dstASs[]=$as->as_num;
		}
		$condition['srcass'] = $srcASs;
		$condition['dstass'] = $dstASs;

		//INPUTs, OUTPUTs
		$inputs = array(); 
		$outputs = array();
		$inouts = $this->InOut_model->getDatas(array('cond_id'=>$cond_id));
		foreach($inouts as $inout)
		{
			if($inout->op=="INPUT")
				$inputs[]=$inout->inout_num;
			else
				$outputs[]=$inout->inout_num;
		}
		$condition['inputs'] = $inputs;
		$condition['outputs'] = $outputs;				

		//icmps
		$icmps = array();
		$datas = $this->CondIcmp_model->getDatas(array('cond_id'=>$cond_id));
		foreach($datas as $data)
		{
			$icmp = $this->IcmpType_model->getRow(array('Id'=>$data->type_id));
			if($icmp == null) continue;
			$icmps[] = array('name'=>$icmp->name, 'type'=>$icmp->value, 'code'=>$data->code);
		}
		$condition['icmps'] = $icmps;

		//tcpflags
		$tcpflags = array();
		$datas = $this->CondTcpFlags_model->getDatas(array('cond_id'=>$cond_id));
		foreach($datas as $data)
		{
			$tcpflags[] = $data->flag;
		}
		$condition['tcpflags'] = $tcpflags;

		//fwdstatus
		$fwdstatus = array();
		$datas = $this->CondFwdStatus_model->getDatas(array('cond_id'=>$cond_id));
		foreach($datas as $data)
		{
			$fwdstatus[] = $data->status;
		}
		$condition['fwdstatus'] = $fwdstatus;
		
		return $this->reply(200, "OK", $condition);
	}

	public function save_condition_opts()
	{
		$this->logonCheck();
		$data =  $this->input->post();

		$condId = $data['cond_id'];
		$oldData = get_object_vars($this->Condition_model->getRow(array('Id'=>$condId)));

		foreach($oldData as $key=>$value)
		{
			if($value=='on')
				$oldData[$key] = 'off';
			if(isset($data[$key]))
				$oldData[$key] = $data[$key];
		}

		unset($oldData['cond_id']);
		$this->Condition_model->updateData(array('Id'=>$condId), $oldData);
		redirect('Cms/condition_edit/'.$condId, 'refresh');
	}

	public function store_flow_record()
	{
		$_POST = json_decode(file_get_contents("php://input"), true); 
		// echo json_encode($_POST);
		// return;

		$nfcapdId = $_POST['nfcapd_id'];
		$filterId = $_POST['filter_id'];
		$record = $_POST['record'];

		$record['update_dt'] = date('Y-m-d H:i:s');
		$cond =array('nfcapd_id'=>$nfcapdId, 'filter_id'=>$filterId, 
			'srcport'=>$record['srcport'], 'dstport'=>$record['dstport'],
			'srcaddr'=>$record['srcaddr'], 'dstaddr'=>$record['dstaddr']);

		$row = $this->Statics_model->getRow($cond);
		if($row!=null)
		{
			$this->Statics_model->updateData(array('Id'=>$row->Id), $record);
		}
		else
		{
			$record['nfcapd_id'] = $nfcapdId;
			$record['filter_id'] = $filterId;
			$this->Statics_model->insertData($record);
		}
		$this->reply(200, 'ok', null);
	}

	public function store_flow_records()
	{
		//$_POST = json_decode(file_get_contents("php://input"), true); 
		$recs = json_decode(file_get_contents("php://input"), true);

		// echo json_encode($_POST);
		// return;

		foreach($recs as $rec)
		{
			$nfcapdId = $rec['nfcapd_id'];
			$filterId = $rec['filter_id'];
			$record = $rec['record'];
	
			$record['update_dt'] = date('Y-m-d H:i:s');
			$cond =array('nfcapd_id'=>$nfcapdId, 'filter_id'=>$filterId, 
				'srcport'=>$record['srcport'], 'dstport'=>$record['dstport'],
				'srcaddr'=>$record['srcaddr'], 'dstaddr'=>$record['dstaddr']);
	
			$row = $this->Statics_model->getRow($cond);
			if($row!=null)
			{
				$this->Statics_model->updateData(array('Id'=>$row->Id), $record);
			}
			else
			{
				$record['nfcapd_id'] = $nfcapdId;
				$record['filter_id'] = $filterId;
				$this->Statics_model->insertData($record);
			}	
		}
		$this->reply(200, 'ok '.count($recs).' records', null);
	}	

	private function makeDurationString($secs)
	{
		$hours = $secs/3600;
		$mins = ($secs%3600)/60;
		$sec =  ($secs%3600)%60;

		$ret = "";
		if($hours > 0) $ret = $hours.'hr';
		if($hours >0 || $mins > 0) $ret .=' '.$mins.'m';
		$ret .=' '.$sec.'s';
		return $ret;
	}

	public function get_statics()
	{
		$this->logonCheck();

		$no = $this->input->post('start');
		$length = $this->input->post('length');

		$datas = $this->Statics_model->getDatasEx(null, $no, $length,'update_dt', 'DESC');
		$total = $this->Statics_model->getCounts(null);

		$resultData = array();
		foreach($datas as $data)
		{
			$nfcapd = $this->Nfcapd_model->getRow(array('Id'=>$data->nfcapd_id));
			if($nfcapd==null) continue;
			$filter = $this->Condition_model->getRow(array('Id'=>$data->filter_id));
			if($filter==null) continue;

			$row = array();
			$row[] = $nfcapd->descr;
			$row[] = $filter->descr;
			$row[] = $data->prot;
			$row[] = $data->tos;
			$row[] = $data->fwd_status;
			$row[] = $data->tcp_flags;
			$row[] = $data->srcaddr;
			$row[] = $data->srcport;
			$row[] = $data->dstaddr;
			$row[] = $data->dstport;
			$row[] = $data->dPkts;
			$row[] = $data->out_pkts;
			$row[] = $data->dOctets;
			$row[] = $data->out_bytes;
			$row[] = $data->ip_router;
			$row[] = $data->srcas;
			$row[] = $data->dstas;
			$row[] = $data->input; 
			$row[] = $data->output;
			$row[] = date('Y-m-d H:i:s', $data->first); 
			$row[] = date('Y-m-d H:i:s', $data->last);
			//$row[] = $this->makeDurationString($data->last - $data->first);

			$row[] = $data->update_dt;
			$resultData[] = $row;
		}
		
		$output = array(
			"draw" => null,
			"recordsTotal" => $total,
			"recordsFiltered" => $total,
			"data" => $resultData,
		);
		echo json_encode($output);		
	}	

}
<?php
defined('BASEPATH') OR exit('No direct script access allowed');



class api extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		// date_default_timezone_set('America/Chicago');
				
		$this->load->model('User_model');
		$this->load->model('Base_model');
		$this->load->model('Condition_model');
		$this->load->model('Nfcapd_model');			

		$this->load->model('Protocol_model');
		$this->load->model('CondProtocols_model');
		$this->load->model('CondIPs_model');		
		$this->load->model('CondPorts_model');		
		$this->load->model('CondVersions_model');		
		$this->load->model('Version_model');	

		$this->load->model('IcmpType_model');			
		$this->load->model('CondIcmp_model');			

		$this->load->model('Router_model');			
		$this->load->model('CondRouters_model');		
		$this->load->model('CondAs_model');
		$this->load->model('InOut_model');
	}

	public function reply($status, $message, $data)
	{
		$result = array('status'=>$status, 'message'=>$message, 'data'=>$data);
		echo json_encode($result);
	}

	public function getFilterCondition()
	{
		$_POST = json_decode(file_get_contents("php://input"), true); 
		$id = $_POST['nfcapd_id'];

		$capd = $this->Nfcapd_model->getRow(array('Id'=>$id));
		if($capd == null)
			return $this->reply(400, "nfcapd no exist", null);
		
		$cond_id = $capd->cond_id;
		$cond = $this->Condition_model->getRow(array('Id'=>$cond_id));
		if($cond == null)
			return $this->reply(400, "condition no exist", null);

		$condition = array();
		$condition['options'] = $cond;

		//SA, DA
		$srcIPs = array(); 
		$dstIPs = array();
		$ips = $this->CondIPs_model->getDatas(array('cond_id'=>$cond_id));
		foreach($ips as $ip)
		{
			if($ip->op=="SRC")
				$srcIPs[]=$ip->ip;
			else
				$dstIPs[]=$ip->ip;
		}
		$condition['saddrs'] = $srcIPs;
		$condition['daddrs'] = $dstIPs;

		//SRCAS, DSTAS
		$srcASs = array(); 
		$dstASs = array();
		$ass = $this->CondAs_model->getDatas(array('cond_id'=>$cond_id));
		foreach($ass as $as)
		{
			if($as->op=="SRC")
				$srcASs[]=$as->as_num;
			else
				$dstASs[]=$as->as_num;
		}
		$condition['srcass'] = $srcASs;
		$condition['dstass'] = $dstASs;

		//INPUTs, OUTPUTs
		$inputs = array(); 
		$outputs = array();
		$inouts = $this->InOut_model->getDatas(array('cond_id'=>$cond_id));
		foreach($inouts as $inout)
		{
			if($inout->op=="INPUT")
				$inputs[]=$inout->inout_num;
			else
				$outputs[]=$inout->inout_num;
		}
		$condition['inputs'] = $inputs;
		$condition['outputs'] = $outputs;


		//ports
		$srcPorts = array(); 
		$dstPorts = array();
		$ports = $this->CondPorts_model->getDatas(array('cond_id'=>$cond_id));
		foreach($ports as $port)
		{
			if($port->op=="SRC")
				$srcPorts[]=$port->port;
			else
				$dstPorts[]=$port->port;
		}
		$condition['sports'] = $srcPorts;
		$condition['dports'] = $dstPorts;

		//protos
		$protos = array();
		$datas = $this->CondProtocols_model->getDatas(array('cond_id'=>$cond_id));
		foreach($datas as $data)
		{
			$proto = $this->Protocol_model->getRow(array('Id'=>$data->protocol_id));
			if($proto == null) continue;
			$protos[]= $proto;
		}
		$condition['protos'] = $protos;

		//versions
		$versions = array();
		$vers = $this->CondVersions_model->getDatas(array('cond_id'=>$cond_id));
		foreach($vers as $ver)
		{
			$version = $this->Version_model->getRow(array('Id'=>$ver->version_id));
			if($version == null) continue;
			$versions[]= $version;
		}
		$condition['versions'] = $versions;

		//icmps
		$icmps = array();
		$datas = $this->CondIcmp_model->getDatas(array('cond_id'=>$cond_id));
		foreach($datas as $data)
		{
			$icmp = $this->IcmpType_model->getRow(array('Id'=>$data->type_id));
			if($icmp == null) continue;
			$icmps[] = array('name'=>$icmp->name, 'type'=>$icmp->value, 'code'=>$data->code);
		}
		$condition['icmps'] = $icmps;

		//routers
		$routers = array();
		$datas = $this->CondRouters_model->getDatas(array('cond_id'=>$cond_id));
		foreach($datas as $data)
		{
			$router = $this->Router_model->getRow(array('Id'=>$data->router_id));
			if($router == null) continue;

			$routers[] = $router;
		}
		$condition['routers'] = $routers;
		
		return $this->reply(200, "OK", $condition);
	}


}
<?php
defined('BASEPATH') OR exit('No direct script access allowed');
include("assets/global/admin.global.php");
class Cms extends CI_Controller {

	public function __construct()
	{
		 parent::__construct();
		 date_default_timezone_set('America/Chicago');
		 		 
		 $this->load->model('User_model');
		 $this->load->model('Base_model');
		 $this->load->model('Condition_model');
		 $this->load->model('Nfcapd_model');			
 
		 $this->load->model('Protocol_model');
		 $this->load->model('CondProtocols_model');
		 $this->load->model('CondIPs_model');		
		 $this->load->model('CondPorts_model');		
		 $this->load->model('CondVersions_model');		
		 $this->load->model('Version_model');	
 
		 $this->load->model('IcmpType_model');			
		 $this->load->model('CondIcmp_model');			
 
		 $this->load->model('Router_model');			
		 $this->load->model('CondRouters_model');

		 $this->load->model('TcpFlag_model');
		 $this->load->model('CondTcpFlags_model');
 
		 $this->load->model('FwdStatus_model');	
		 $this->load->model('CondFwdStatus_model');	
		 $this->load->model('CondSubNets_model');		 	
  		  
	}
	
	public function index()
	{
		if($this->logonCheck()) {
			redirect('Cms/dashboard/', 'refresh');
		} 
	}
	public function login(){
		$this->load->view("admin/view_login");
	}

	public function logout(){
		$this->session->sess_destroy();
		redirect('Cms/', 'refresh');
	}

	public function auth_user() {
		global $MYSQL;
		$email = $this->input->post('email');
		$password = $this->input->post('password');
		$conAry = array('email' => $email);
		$ret = $this->User_model->getRow($MYSQL['_adminDB'], $conAry);
		if(!empty($ret)){       
			if (password_verify($password, $ret->password)) {       
				$sess_data = array('user_id'=>$ret->Id, 'is_login'=>true);
				$this->session->set_userdata($sess_data);
				redirect('Cms/dashboard/', 'refresh');
			}
		} 
		redirect( 'Cms/login', 'refresh');
	}
	public function dashboard() {
		if($this->logonCheck()) {
			global $MYSQL;
			$param['uri'] = '';
			$param['kind'] = '';

			$this->load->view("admin/view_header", $param);	

			$data['guest_cnt'] = 0;
			$data['expert_cnt'] = 0;
			$data['user_cnt'] = 0;

			$data['quest_cnt'] = 0;
			$data['answer_cnt'] = 0;
			$data['comment_cnt'] = 0;
			$this->load->view("admin/view_dashboard", $data);
		}
	}
	public function updateAccount() {
		if($this->logonCheck()){
			global $MYSQL;
			$email = $this->input->post('email');
			$password = $this->input->post('password');
			$id = $this->session->userdata('user_id');
			$npass = password_hash($password, PASSWORD_DEFAULT);
			$updateAry = array('email'=>$email,
				'password'=>$npass,
				'modified'=>date('Y-m-d'));
			$ret = $this->User_model->updateData($MYSQL['_adminDB'], array('Id'=>$id), $updateAry);
			if($ret > 0) 
				$this->session->set_flashdata('messagePr', 'Update Account Successfully..');
			else
				$this->session->set_flashdata('messagePr', 'Unable to Update Account..');
			redirect('Cms/dashboard/', 'refresh');
		}
	}

	public function conditions()
	{
		if(!$this->logonCheck()) return;
		$param['uri'] = 'conditions';
		$param['kind'] = 'table';
		$param['table'] = 'tbl_condition';
	
		$this->load->view("admin/view_header", $param);
		$this->load->view("admin/view_condition",$param);
		$this->load->view("admin/view_footer",$param);
	}		

	public function nfcapds()
	{
		if(!$this->logonCheck()) return;
		$param['uri'] = 'nfcapds';
		$param['kind'] = 'table';
		$param['table'] = 'tbl_nfcapd';
		$param['conds'] = $this->Condition_model->getDatas(null);
	
		$this->load->view("admin/view_header", $param);
		$this->load->view("admin/view_nfcapd",$param);
		$this->load->view("admin/view_footer",$param);
	}	

	public function condition_edit($id=1)
	{
		if(!$this->logonCheck()) return;

		$param['uri'] = 'condition_edit';
		$param['kind'] = 'table';
		$param['table'] = 'tbl_condition';

		$param['versions'] = $this->Version_model->getDatas(null);
		$param['protos'] = $this->Protocol_model->getDatas(null);
		$param['icmpTypes'] = $this->IcmpType_model->getDatas(null);		
		$param['routers'] = $this->Router_model->getDatas(null);	
		$param['tcpFlags'] = $this->TcpFlag_model->getDatas(null);
		$param['fwdStatus'] = $this->FwdStatus_model->getDatas(null);

		$cond = $this->Condition_model->getRow(array('Id'=>$id));	
		$param['cond'] = $cond;
		$param['cond_id'] = $id;		
		
		$this->load->view("admin/view_header", $param);
		$this->load->view("admin/view_condition_edit",$param);
		$this->load->view("admin/view_footer",$param);
	}	

	public function versions()
	{
		if(!$this->logonCheck()) return;

		$param['uri'] = 'versions';
		$param['kind'] = 'table';
		$param['table'] = 'tbl_protocol_versions';
	
		$this->load->view("admin/view_header", $param);
		$this->load->view("admin/view_versions",$param);
		$this->load->view("admin/view_footer",$param);
	}

	public function statics()
	{
		if(!$this->logonCheck()) return;

		$param['uri'] = 'statics';
		$param['kind'] = 'table';
		$param['table'] = 'tbl_statics';
	
		$this->load->view("admin/view_header", $param);
		$this->load->view("admin/view_statics",$param);
		$this->load->view("admin/view_footer",$param);
	}

	public function protocols()
	{
		if(!$this->logonCheck()) return;

		$param['uri'] = 'protocols';
		$param['kind'] = 'table';
		$param['table'] = 'tbl_protocols';
	
		$this->load->view("admin/view_header", $param);
		$this->load->view("admin/view_protocols",$param);
		$this->load->view("admin/view_footer",$param);
	}	

	public function icmp_types()
	{
		if(!$this->logonCheck()) return;

		$param['uri'] = 'icmp_types';
		$param['kind'] = 'table';
		$param['table'] = 'tbl_icmp_types';
	
		$this->load->view("admin/view_header", $param);
		$this->load->view("admin/view_icmp_types",$param);
		$this->load->view("admin/view_footer",$param);
	}	

	public function routers()
	{
		if(!$this->logonCheck()) return;

		$param['uri'] = 'routers';
		$param['kind'] = 'table';
		$param['table'] = 'tbl_router';
	
		$this->load->view("admin/view_header", $param);
		$this->load->view("admin/view_routers",$param);
		$this->load->view("admin/view_footer",$param);
	}	

	public function tcp_flags()
	{
		if(!$this->logonCheck()) return;

		$param['uri'] = 'tcp_flags';
		$param['kind'] = 'table';
		$param['table'] = 'tbl_tcp_flag';
	
		$this->load->view("admin/view_header", $param);
		$this->load->view("admin/view_tcp_flags",$param);
		$this->load->view("admin/view_footer",$param);
	}	
	public function fwd_status()
	{
		if(!$this->logonCheck()) return;

		$param['uri'] = 'fwd_status';
		$param['kind'] = 'table';
		$param['table'] = 'tbl_fwd_status';
	
		$this->load->view("admin/view_header", $param);
		$this->load->view("admin/view_fwd_status",$param);
		$this->load->view("admin/view_footer",$param);
	}	


}
